// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonTxtbox
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonTxtbox"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_txtbox display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_TXTBOX
#define _H_NONNON_MAC_NONNON_TXTBOX




#import <Cocoa/Cocoa.h>


#include "../neutral/bmp/ui/rectframe.c"
#include "../neutral/bmp/ui/roundframe.c"

#include "../neutral/txt.c"

#include "../game/helper.c"



#include "_mac.c"
#include "image.c"
#include "window.c"

//#include "n_listbox.c"


#include "n_txtbox/00_codec.c"
#include "n_txtbox/01_character.c"
#include "n_txtbox/02_caret.c"
#include "n_txtbox/03_selection.c"
#include "n_txtbox/04_edit.c"




typedef struct {

	n_type_int x;
	n_type_int y;

} n_point_cch;

typedef struct {

	CGPoint     pxl;
	n_point_cch cch;

} n_caret;

n_caret
NonnonMakeCaret( CGFloat pxl_x, CGFloat pxl_y, n_type_int cch_x, n_type_int cch_y )
{

	n_caret caret = { pxl_x, pxl_y, cch_x, cch_y };

	return caret;
}




typedef struct {

	n_txt   txt;
	CGFloat scroll;
	CGFloat focus;
	n_caret caret_fr;
	n_caret caret_to;

} n_undo;

#define n_undo_zero( p ) n_memory_zero( p, sizeof( n_undo ) )

#define N_TXTBOX_UNDO_RESTORE  ( 0 )
#define N_TXTBOX_UNDO_SUSPEND  ( 1 )
#define N_TXTBOX_UNDO_REGISTER ( 2 )
#define N_TXTBOX_UNDO_RESET    ( 3 )




#define N_MAC_TXTBOX_DRAW_LINENUMBER_NONE            ( 0 << 0 )
#define N_MAC_TXTBOX_DRAW_LINENUMBER_ZEROBASED_INDEX ( 1 << 0 )

// internal
void
n_mac_txtbox_draw_linenumber
(
	      NSFont *font,
	  n_type_int  index,
	  n_type_int  offset,
	  n_type_int  txt_sy,
	  n_type_int  focus_f,
	  n_type_int  focus_t,
	  n_type_gfx   x,
	  n_type_gfx   y,
	  n_type_gfx  sx,
	  n_type_gfx  sy,
	     NSColor *color_back,
	     NSColor *color_text,
	         int  option
)
{
//return;

	n_type_int cch_y = index + offset;

	if ( option & N_MAC_TXTBOX_DRAW_LINENUMBER_ZEROBASED_INDEX )
	{
		//
	} else {
		cch_y++;
	}

	n_posix_bool over_ten_thousand = n_posix_false;
	if ( cch_y >= 10000 ) { over_ten_thousand = n_posix_true; }

	if ( cch_y >= 10000 ) { cch_y = cch_y % 10000; }

	//n_posix_char str[ 6 + 1 ];
	NSString *nsstr;

	// [Patch] : not working accurately

	if ( cch_y < 1000 )
	{
		if ( over_ten_thousand )
		{
			//n_posix_sprintf_literal( str, " %04d ", (int) cch_y );
			nsstr = [[NSString alloc] initWithFormat:@" %04d ", (int) cch_y];
		} else {
			//n_posix_sprintf_literal( str, " % 4d ", (int) cch_y );
			nsstr = [[NSString alloc] initWithFormat:@" % 4d ", (int) cch_y];
		}
	} else {
		//n_posix_sprintf_literal( str, " %d "  , (int) cch_y );
		nsstr = [[NSString alloc] initWithFormat:@" %d ", (int) cch_y];
	}


	NSColor *color_stripe;
	if ( ( index + offset ) & 1 )
	{
		color_stripe = [color_text blendedColorWithFraction:0.90 ofColor:color_back];
	} else {
		color_stripe = [color_text blendedColorWithFraction:0.95 ofColor:color_back];
	}

	NSRect rect = NSMakeRect( x,y,sx,sy );

	[color_stripe set];
	[NSBezierPath fillRect:rect];

	if ( ( index + offset ) < txt_sy )
	{

		NSColor *color_txt;
		if ( ( ( index + offset ) >= focus_f )&&( ( index + offset ) <= focus_t ) )
		{
			// [!] : indicator

			n_type_gfx size = 2;

			NSRect r = NSMakeRect( x,y,size,sy );

			[[NSColor controlAccentColor] set];
			[NSBezierPath fillRect:r];

			color_txt = [color_text blendedColorWithFraction:0.33 ofColor:color_back];
		} else {
			color_txt = [color_text blendedColorWithFraction:0.66 ofColor:color_back];
		}


		NSMutableDictionary *attr = [NSMutableDictionary dictionary];
		[attr setObject:font      forKey:NSFontAttributeName           ];
		[attr setObject:color_txt forKey:NSForegroundColorAttributeName];

		[nsstr drawInRect:rect withAttributes:attr];

	}


	return;
}

n_caret
n_txtbox_caret_detect_pixel2caret
(
	n_txt      *txt,
	n_type_int  focus,
	NSRect      rect,
	NSFont     *font,
	CGSize      font_size,
	NSPoint     local_point
)
{

	n_posix_char *line = n_txt_get( txt, focus );


	n_type_int index = 0;
	CGFloat    sx    = 0;
	n_type_int tab   = 0;
	n_type_int cch   = 0;
	n_posix_loop
	{//break;
		if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

		CGSize     char_size;
		n_type_int char_index;
		NSRect     char_rect = rect;

		n_posix_char *character;
		character = n_mac_txtbox_character( font, font_size, (u8*) line, index, &char_size, &char_index, &tab );

		CGFloat half_sx = char_size.width / 2;

		sx += half_sx;
		char_rect.origin.x = rect.origin.x + sx;
		if ( char_rect.origin.x > local_point.x ) { sx -= half_sx; break; }

		sx += half_sx;
		char_rect.origin.x = rect.origin.x + sx;
		if ( char_rect.origin.x > local_point.x ) { break; }

		index += char_index;
		cch = index;
	}


	return NonnonMakeCaret( sx, focus * font_size.height, cch, focus );
}

n_caret
n_txtbox_caret_detect_cch2pixel
(
	n_txt      *txt,
	n_type_int  focus,
	NSFont     *font,
	CGSize      font_size,
	n_type_int  caret_cch
)
{
//NSLog( @"%lld", caret_cch );

	n_posix_char *line = n_txt_get( txt, focus );


	n_type_int index = 0;
	CGFloat    sx    = 0;
	n_type_int tab   = 0;
	n_posix_loop
	{//break;
		if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

		CGSize     char_size;
		n_type_int char_index;

		n_mac_txtbox_character( font, font_size, (u8*) line, index, &char_size, &char_index, &tab );

		if ( index >= caret_cch ) { break; }

		sx    += char_size.width;
		index += char_index;

	}

//NSLog( @"%f", sx );
	return NonnonMakeCaret( sx, focus * font_size.height, caret_cch, focus );
}




@interface NonnonTxtbox : NSView
//@interface NonnonTxtbox : NSView <NSTextInputClient>

@end


@interface NonnonTxtbox ()

@property CGFloat  n_focus;
@property n_txt   *n_txt;

@end


@implementation NonnonTxtbox {

	NSString   *path;

	n_bmp       canvas;
	NSFont     *font;
	CGSize      font_size;
	CGFloat     scroll;
	CGPoint     pt;
	NSRect      scroller_rect_thumb;
	NSRect      scroller_rect_shaft;
	CGFloat     offset;
	CGFloat     margin;
	CGFloat     padding;
	BOOL        thumb_is_captured;
	BOOL        thumb_is_hovered;
	BOOL        shaft_is_hovered;
	CGFloat     thumb_offset;
	n_bmp_fade  fade;
	CGFloat     client_sy;
	n_type_int  redraw_fy;
	n_type_int  redraw_ty;

	CGSize      linenumber_size;
	u32         linenumber_color_back;
	u32         linenumber_color_text;

	CGPoint     caret_pt;
	n_caret     caret_fr;
	n_caret     caret_to;

	BOOL        shift_selection_is_tail;

	n_undo      undo;
	n_undo      undo_tmp;
	BOOL        undo_timer_queue;
	u32         undo_timer;

	n_bmp       bmp_cache[ 128 ];

}




@synthesize n_focus;
@synthesize n_txt;




-(void) n_txtbox_bitmap_cache
{

	if ( font.fixedPitch == NO ) { return; }

	int i = 0;
	n_posix_loop
	{

		n_posix_char  str[ 2 ] = { i, 0 };
		NSString     *nsstring = [NSString stringWithFormat:@"%s", str];

		n_bmp_zero( &bmp_cache[ i ] );
		n_bmp_new ( &bmp_cache[ i ], font_size.width * 2, font_size.height * 2 );

		n_mac_image_text( &bmp_cache[ i ], nsstring, font, n_bmp_white, 0, 0, 0,0, N_MAC_IMAGE_TEXT_CENTER );
		n_bmp_resizer   ( &bmp_cache[ i ], font_size.width, font_size.height, 0, N_BMP_RESIZER_CENTER );


		i++;
		if ( i >= 128 ) { break; }
	}

}




- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{

		n_bmp_safemode = n_posix_false;

		n_bmp_transparent_onoff_default = n_posix_false;


		{
			NSArray      *paths   = NSSearchPathForDirectoriesInDomains( NSDesktopDirectory, NSUserDomainMask, YES );
			NSString     *desktop = [paths objectAtIndex:0];
			n_posix_char  tmpname[ 100 ]; n_string_path_tmpname( tmpname );

	    		path = [NSString stringWithFormat:@"%@/%s.txt", desktop, tmpname];
//NSLog( @"%@", path );
		}


		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];


		n_bmp_zero( &canvas );

		//font      = [NSFont monospacedSystemFontOfSize:14 weight:NSFontWeightRegular];
		//font      = [NSFont systemFontOfSize:14 weight:NSFontWeightRegular];
		font      = [NSFont userFixedPitchFontOfSize:14];

		font_size = n_mac_image_text_pixelsize( @" ", font );

		linenumber_size = n_mac_image_text_pixelsize( @"000000", font );

		offset    = 6;
		margin    = 3;
		padding   = offset + linenumber_size.width + margin;

		[self n_reset];

		n_bmp_fade_init( &fade, n_bmp_black );

		[self n_txtbox_bitmap_cache];

		n_undo_zero( &undo );
		n_txt_zero( &undo.txt ); n_txt_utf8_new( &undo.txt );

		n_mac_timer_init( self, @selector( n_undo_timer ), 500 );


		n_mac_timer_init( self, @selector( n_timer_method ), 33 );

	}
	
	return self;
}


- (void) n_timer_method
{

	if ( thumb_is_captured ) { return; }


	static BOOL prv = FALSE;

	thumb_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, scroller_rect_thumb );

	if ( thumb_is_hovered != prv )
	{
//[self display];
		if ( thumb_is_hovered )
		{
			n_bmp_fade_go( &fade, n_bmp_white );
		} else {
			n_bmp_fade_go( &fade, n_bmp_black );
		}
	}

	n_bmp_fade_engine( &fade, n_posix_true );
//NSLog( @"%d", fade.percent );
	if ( fade.stop == n_posix_false )
	{
		[self display];
	}

	prv = thumb_is_hovered;

}


- (BOOL) isFlipped
{
	return YES;
}


- (void) n_reset
{

	scroll  = 0;
	n_focus = 0;

	scroller_rect_thumb = NSMakeRect( 0,0,0,0 );
	scroller_rect_shaft = NSMakeRect( 0,0,0,0 );

	thumb_is_hovered = FALSE;


	caret_pt = NSMakePoint( 0, 0 );
	
	caret_fr = NonnonMakeCaret( 0,0,0,0 );
	caret_to = NonnonMakeCaret( 0,0,0,0 );

	shift_selection_is_tail = TRUE;


	undo_timer_queue = FALSE;
	undo_timer       = n_posix_tickcount();


	redraw_fy = -1;
	redraw_ty = -1;

}




- (void) n_undo_timer
{

	if ( undo_timer_queue )
	{
		if ( n_game_timer( &undo_timer, 3000 ) )
		{
//NSLog( @"regsitered" );
			undo_timer_queue = FALSE;
			[self n_undo:N_TXTBOX_UNDO_REGISTER];
		}
	}

}

- (void) n_undo:(int) action
{

	if ( action == N_TXTBOX_UNDO_RESTORE )
	{
		n_txt_copy( &undo.txt, n_txt );

		scroll   = undo.scroll;
		n_focus  = undo.focus;
		caret_fr = undo.caret_fr;
		caret_to = undo.caret_to;
	} else
	if ( action == N_TXTBOX_UNDO_SUSPEND )
	{
		n_txt_copy( n_txt, &undo_tmp.txt );

		undo_tmp.scroll   = scroll;
		undo_tmp.focus    = n_focus;
		undo_tmp.caret_fr = caret_fr;
		undo_tmp.caret_to = caret_to;

		undo_timer_queue = TRUE;
		undo_timer       = n_posix_tickcount();
	} else
	if ( action == N_TXTBOX_UNDO_REGISTER )
	{
		n_txt_copy( &undo_tmp.txt, &undo.txt );

		undo.scroll   = undo_tmp.scroll;
		undo.focus    = undo_tmp.focus;
		undo.caret_fr = undo_tmp.caret_fr;
		undo.caret_to = undo_tmp.caret_to;
	} else
	if ( action == N_TXTBOX_UNDO_RESET )
	{
		n_txt_copy( n_txt, &undo_tmp.txt );

		undo_tmp.scroll   = scroll;
		undo_tmp.focus    = n_focus;
		undo_tmp.caret_fr = caret_fr;
		undo_tmp.caret_to = caret_to;

		n_txt_copy( &undo_tmp.txt, &undo.txt );

		undo.scroll   = undo_tmp.scroll;
		undo.focus    = undo_tmp.focus;
		undo.caret_fr = undo_tmp.caret_fr;
		undo.caret_to = undo_tmp.caret_to;
	}

}




- (void) n_scroll_clamp
{

	CGFloat o                = offset;
	CGFloat items_per_canvas = ( self.frame.size.height - ( o * 2 ) ) / font_size.height;
	CGFloat txt_sy           = n_txt->sy;
//NSLog( @"%f %f", page, txt_sy );

	if ( txt_sy <= 1 )
	{
		scroll = 0;
	} else
	if ( items_per_canvas <= txt_sy )
	{
		if ( fabs( items_per_canvas ) ) { items_per_canvas -= 1.0; }

		CGFloat max_sy = txt_sy - items_per_canvas;

		if ( scroll <       0 ) { scroll =      0; } else
		if ( scroll >= max_sy ) { scroll = max_sy; }
	} else {
		scroll = 0;
	}

}

-(void) n_caret_out_of_canvas_ud
{

	CGFloat csy              = self.frame.size.height - ( offset * 2 );
	CGFloat items_per_canvas = csy / font_size.height;


	CGFloat minim = MIN( caret_fr.cch.y, caret_to.cch.y );
	CGFloat maxim = MAX( caret_fr.cch.y, caret_to.cch.y );

	if ( minim < scroll )
	{
//NSLog( @"up" );
		if ( ( minim - 1 ) == scroll )
		{
			scroll--;
		} else {
			scroll = minim - ( items_per_canvas / 2 );
		}
	} else
	if ( maxim >= ( scroll + items_per_canvas - 1 ) )
	{
//NSLog( @"down : %f %f", maxim, ( scroll + items_per_canvas - 1 ) );

		if ( trunc( maxim - 1 ) == trunc( scroll + items_per_canvas - 1 ) )
		{
			scroll++;
		} else {
			scroll = maxim - ( items_per_canvas / 2 );
		}
	}

}

-(void) n_caret_out_of_canvas_lr
{

	CGFloat csy              = self.frame.size.height - ( offset * 2 );
	CGFloat items_per_canvas = csy / font_size.height;


	CGFloat minim = MIN( caret_fr.cch.y, caret_to.cch.y );
	CGFloat maxim = MAX( caret_fr.cch.y, caret_to.cch.y );

	if ( minim < scroll )
	{
//NSLog( @"up" );
		scroll = minim - ( items_per_canvas / 2 );
	} else
	if ( maxim >= ( scroll + items_per_canvas - 1 ) )
	{
//NSLog( @"down : %f %f", maxim, ( scroll + items_per_canvas - 1 ) );
		scroll = maxim - ( items_per_canvas / 2 );
	}

}




- (n_caret) n_detect_cursor
{

	NSPoint local_point = n_mac_cursor_position_get( self );

	n_focus = trunc( scroll + trunc( ( local_point.y - offset ) / font_size.height ) );
	if ( n_focus >= n_txt->sy ) { n_focus = n_txt->sy - 1; }
//NSLog( @"%f", n_focus );

	NSRect r = NSMakeRect( padding - font_size.width, offset, [self frame].size.width - ( offset * 2 ), font_size.height );

	n_caret caret = n_txtbox_caret_detect_pixel2caret
	(
		n_txt,
		n_focus,
		r,
		font,
		font_size,
		local_point
	);

	caret = n_txtbox_caret_detect_cch2pixel
	(
		n_txt,
		n_focus,
		font,
		font_size,
		caret.cch.x
	);


	return caret;
}

- (void) n_detect_tripleclick
{
//NSLog( @"%f", n_focus );


	n_posix_char *line = n_txt_get( n_txt, n_focus );


	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		n_txt,
		n_focus,
		font,
		font_size,
		n_posix_strlen( line )
	);


	caret_fr.pxl.x = 0;
	caret_to.pxl.x = caret.pxl.x;

	caret_fr.cch.y = n_focus;
	caret_to.cch.y = n_focus;

	caret_fr.pxl.y = n_focus * font_size.height;
	caret_to.pxl.y = n_focus * font_size.height;

	shift_selection_is_tail = TRUE;


	return;
}

- (void) n_detect_doubleclick
{
//return;

	n_posix_char *line = n_txt_get( n_txt, n_focus );

	if (
		( line[ caret_fr.cch.x ] ==  ' ' )
		||
		( line[ caret_fr.cch.x ] == '\t' )
	)
	{

		{

			n_type_int cch_fr = caret_fr.cch.x;
			n_posix_loop
			{
				if ( cch_fr < 0 ) { break; }

//NSLog( @"%c", line[ cch_fr ] );

				if (
					( line[ cch_fr ] !=  ' ' )
					&&
					( line[ cch_fr ] != '\t' )
				)
				{
					cch_fr++;
					break;
				}

				cch_fr--;
			}


			caret_fr = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				cch_fr
			);

		}

		{

			n_type_int cch_to = caret_to.cch.x;
			n_posix_loop
			{
				if ( line[ cch_to ] == '\0' ) { break; }

				if (
					( line[ cch_to ] !=  ' ' )
					&&
					( line[ cch_to ] != '\t' )
				)
				{
					break;
				}

				cch_to++;
			}


			caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				cch_to
			);

		}


		return;
	}

	{

		BOOL is_blank = FALSE;

		n_type_int cch_fr = caret_fr.cch.x;
		n_posix_loop
		{
			if ( cch_fr < 0 ) { break; }

//NSLog( @"%c", line[ cch_fr ] );

			if ( line[ cch_fr ] ==  ' ' ) { is_blank = TRUE; break; }
			if ( line[ cch_fr ] == '\t' ) { is_blank = TRUE; break; }

			cch_fr--;
		}

		if ( ( is_blank )&&( cch_fr != caret_fr.cch.x ) ) { cch_fr++; }


		caret_fr = n_txtbox_caret_detect_cch2pixel
		(
			n_txt,
			n_focus,
			font,
			font_size,
			cch_fr
		);

	}


	{

		n_type_int cch_to = caret_to.cch.x;
		n_posix_loop
		{
			if ( line[ cch_to ] == '\0' ) { break; }
			if ( line[ cch_to ] ==  ' ' ) { break; }
			if ( line[ cch_to ] == '\t' ) { break; }

			cch_to++;
		}


		caret_to = n_txtbox_caret_detect_cch2pixel
		(
			n_txt,
			n_focus,
			font,
			font_size,
			cch_to
		);

	}


	shift_selection_is_tail = TRUE;


	return;	
}

- (void) n_detect_key_move:(void*) zero ud:(n_type_int)ud lr:(n_type_int)lr 
{
//NSLog( @"%f", n_focus );


	// [!] : unselect

	if ( ( caret_fr.pxl.x != caret_to.pxl.x )&&( caret_fr.cch.y != caret_to.cch.y ) )
	{
		caret_fr = caret_to;
	}


	n_focus += ud;
	if ( n_focus < 0 )
	{
		if ( n_focus <= -1 ) { caret_fr.cch.x = 0; }
		n_focus = 0;
	}
	if ( n_focus >= n_txt->sy ) { n_focus = n_txt->sy - 1; }


	if ( ud )
	{
		NSRect r = NSMakeRect( padding, offset, [self frame].size.width - ( offset * 2 ), font_size.height );

		caret_fr = n_txtbox_caret_detect_pixel2caret
		(
			n_txt,
			n_focus,
			r,
			font,
			font_size,
			NSMakePoint( padding + caret_fr.pxl.x, caret_fr.cch.y + font_size.height )
		);
//NSLog( @"%0.2f", caret_fr.pxl.x );

		// [!] : Win32 compatible behavior 
		if ( caret_fr.pxl.x == 0 ) { caret_fr.cch.x = 0; }
	}


	if ( lr != 0 )
	{
		n_posix_char *s = n_txt_get( n_txt, n_focus );
		if ( lr < 0 )
		{
			if ( caret_fr.cch.x == 0 )
			{
				if ( n_focus != 0 )
				{
					n_focus--;
					caret_fr.cch.x = caret_to.cch.x = n_posix_strlen( n_txt_get( n_txt, n_focus ) );
				}
			} else {
				caret_fr.cch.x = caret_to.cch.x = n_mac_txtbox_caret_move( s, caret_fr.cch.x, N_MAC_TXTBOX_CARET_MOVE_L );	
			}
		} else {
			if ( caret_fr.cch.x == n_posix_strlen( n_txt_get( n_txt, n_focus ) ) )
			{
				n_type_int max_sy = n_txt->sy - 1;
				if ( n_focus < max_sy )
				{
					n_focus++;
					caret_fr.cch.x = 0;
				}
			} else {
				caret_fr.cch.x = n_mac_txtbox_caret_move( s, caret_fr.cch.x, N_MAC_TXTBOX_CARET_MOVE_R );	
			}
		}
	}


	caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
	(
		n_txt,
		n_focus,
		font,
		font_size,
		caret_fr.cch.x
	);


	return;
}

- (n_caret) n_detect_key_shift_selection:(void*)zero lr:(n_type_int)lr cch:(n_type_int)cch
{
//NSLog( @"%f", n_focus );

	n_posix_char *s = n_txt_get( n_txt, n_focus );
	if ( lr < 0 )
	{
		cch = n_mac_txtbox_caret_move( s, cch, N_MAC_TXTBOX_CARET_MOVE_L );
	} else {
		cch = n_mac_txtbox_caret_move( s, cch, N_MAC_TXTBOX_CARET_MOVE_R );
	}
//NSLog( @"%lld", (*cch) );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		n_txt,
		n_focus,
		font,
		font_size,
		cch
	);


	return caret;
}



- (void) n_caret_calc
{

	// [!] : caret on the current screen

	n_caret pt = caret_fr;

	if ( caret_fr.cch.y == caret_to.cch.y )
	{
		if ( caret_fr.cch.y == n_focus )
		{
			if ( caret_fr.pxl.x == caret_to.pxl.x )
			{
//NSLog( @"==" );
				//
			} else
			if ( caret_fr.pxl.x < caret_to.pxl.x )
			{
//NSLog( @"< : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = caret_to;
			} else {
//NSLog( @"> : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = caret_to;
			}
		}
	} else
	if ( caret_fr.cch.y < caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { pt = caret_to; }
	} else
	if ( caret_fr.cch.y > caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { pt = caret_to; }
	}

	caret_pt.x = padding + pt.pxl.x;
	caret_pt.y = offset + ( ( pt.cch.y - trunc( scroll ) ) * font_size.height );


	return;
}

- (BOOL) n_caret_on_screen
{

	[self n_caret_calc];


	BOOL ret = FALSE;

	if ( caret_fr.cch.y == caret_to.cch.y )
	{
		if ( caret_fr.cch.y == n_focus ) { ret = TRUE; }
	} else
	if ( caret_fr.cch.y < caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { ret = TRUE; }
	} else
	if ( caret_fr.cch.y > caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { ret = TRUE; }
	}


	return ret;
}




- (void)drawRect:(NSRect)rect
{
//NSLog( @"drawRect" );

u32 tick = n_posix_tickcount();

//NSLog( @"%lld", n_test_txt.sy );


	// [!] : redraw

	// [x] : partial redraw is not available
	//
	//	drawRect will be called with as gray-filled image

	//if ( redraw_fy == -1 )
	{
		redraw_fy = 0;
		redraw_ty = n_txt->sy;
	}

	//redraw_fy = 3;
	//redraw_ty = 6;

	BOOL is_not_partial = ( ( redraw_fy == 0 )&&( redraw_ty == n_txt->sy ) );


	// [!] : Metrics

	[self n_scroll_clamp];

	n_type_gfx sx = (n_type_gfx) rect.size.width;
	n_type_gfx sy = (n_type_gfx) rect.size.height;

	CGFloat o = offset;
	//CGFloat m = margin;

	CGFloat minim = font_size.height + ( o * 2 );
	if ( ( sx < minim )||( sy < minim ) ) { return; }

	if ( caret_fr.cch.y >= n_txt->sy ) { caret_fr.cch.y = n_txt->sy - 1; }


	// [!] : Metrics 2 : Colors

	NSColor *nscolor_text   = [NSColor textColor];
	NSColor *nscolor_back   = [NSColor textBackgroundColor];
	u32        color_bg     = n_mac_nscolor2argb( nscolor_back );
	u32        color_fg     = n_mac_nscolor2argb( nscolor_text );
	u32        color_frame  = n_bmp_blend_pixel( color_bg, color_fg, 0.25 );
	u32        color_stripe = n_bmp_blend_pixel( color_bg, color_fg, 0.05 );
	u32        color_crlf   = n_bmp_blend_pixel( color_bg, color_fg, 0.25 );
	NSColor *nscolor_text_normal    = nscolor_text;
	NSColor *nscolor_text_highlight = [NSColor controlHighlightColor];
	NSColor *nscolor_stripe         = n_mac_argb2nscolor( color_stripe );
	NSColor *nscolor_accent         = [NSColor controlAccentColor];
	NSColor *nscolor_crlf           = n_mac_argb2nscolor( color_crlf );


	// [!] : Contents

	static n_type_gfx prv_sx = -1;
	static n_type_gfx prv_sy = -1;

	if ( ( sx != prv_sx )||( sy != prv_sy ) )
	{
		n_bmp_new_fast( &canvas, sx,sy );
	}

	prv_sx = sx;
	prv_sy = sy;


	n_bmp_flush( &canvas, n_bmp_black_invisible );


	if ( is_not_partial )
	{
		[nscolor_back set];
		[NSBezierPath fillRect:rect];
	}


	// [!] : n_txt rendering engine

//NSLog( @"%f %f", caret_fr.pxl.x, caret_to.pxl.x );

	NSMutableDictionary *attr = [NSMutableDictionary dictionary];
	[attr setObject:font forKey:NSFontAttributeName ];

	NSMutableDictionary *attr_crlf = [NSMutableDictionary dictionary];
	[attr_crlf setObject:font forKey:NSFontAttributeName ];
	[attr_crlf setObject:nscolor_crlf forKey:NSForegroundColorAttributeName];


	NSRect r = NSMakeRect( padding, o, rect.size.width - ( o * 2 ), font_size.height );

	CGFloat max_sy = rect.size.height - ( o * 2 );

	n_type_int i = scroll;
//NSLog( @"%f %lld", scroll, n_mac_listbox_txt.sy );
	n_posix_loop
	{//break;

		const n_posix_char *line = n_txt_get( n_txt, i );

		if (
			( is_not_partial )
			||
			( ( redraw_fy <= i )&&( i < redraw_ty ) )
		)
		{
			if ( i & 1 )
			{
				[nscolor_stripe set];
				[NSBezierPath fillRect:r];
			} else {
				[nscolor_back set];
				[NSBezierPath fillRect:r];
			}
		}

		if ( ( redraw_fy <= i )&&( i < redraw_ty )&&( i < n_txt->sy ) )
		{
//[text drawInRect:r withAttributes:attr];

			n_type_int index = 0;
			CGFloat    sx    = 0;
			n_type_int tab   = 0;
			n_posix_loop
			{//break;
				if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

				CGSize     char_size;
				n_type_int char_index;
				NSRect     char_rect = r;

				n_posix_char *character;
				character = n_mac_txtbox_character( font, font_size, (u8*) line, index, &char_size, &char_index, &tab );
//NSLog( @"#%lld : %ld", i, strlen( character ) );

				char_rect.origin.x   += sx;
				char_rect.origin.x   -= 1;
				char_rect.size.width  = char_size.width + 1;


				NSPoint pt = NSMakePoint( sx, i );

				BOOL selected = n_mac_txtbox_is_selected( pt, caret_fr.pxl.x, caret_fr.cch.y, caret_to.pxl.x, caret_to.cch.y );
				if ( selected )
				{
					[nscolor_accent set];
					[NSBezierPath fillRect:char_rect];
				}

				int n = (u8) line[ index ];

				if ( line[ index ] == N_STRING_CHAR_TAB )
				{

					NSRect r = char_rect; r.size.width = 0.5;

					[nscolor_crlf set];
					[NSBezierPath fillRect:r];

				} else
				if ( ( font.fixedPitch == YES )&&( n < 128 ) )
				{
//NSLog( @"%d", n );
					n_posix_bool flip_prv = n_bmp_flip_onoff;
					n_bmp_flip_onoff = n_posix_true;

					n_type_gfx  x = char_rect.origin.x;
					n_type_gfx  y = char_rect.origin.y;
					//n_type_gfx sx = char_rect.size.width;
					//n_type_gfx sy = char_rect.size.height;
//n_bmp_box( &frame, x,y, sx, sy, n_bmp_rgb(111,111,111) );


					u32 local_color_text;
					if ( selected )
					{
						local_color_text = n_mac_nscolor2argb( nscolor_text_highlight );
					} else {
						local_color_text = n_mac_nscolor2argb( nscolor_text_normal    );
					}

					n_bmp_rasterizer( &bmp_cache[ n ], &canvas, x,y, local_color_text, FALSE );

					n_bmp_flip_onoff = flip_prv;

				} else {

					if ( selected )
					{
						[attr setObject:nscolor_text_highlight forKey:NSForegroundColorAttributeName];
					} else {
						[attr setObject:nscolor_text_normal    forKey:NSForegroundColorAttributeName];
					}

					NSString *text = n_mac_str2nsstring( character );
					[text drawInRect:char_rect withAttributes:attr];

				}


				index += char_index;
				sx    += char_size.width;
			}


			{
				NSRect rect = r;
				rect.origin.x += sx;

				NSString *crlf = @"\xe2\x86\xa9";
				[crlf drawInRect:rect withAttributes:attr_crlf];
			}

		}


		r.origin.y += font_size.height;
		if ( r.origin.y > max_sy ) { break; }


		i++;
	}


	// [!] : Line Number

	if ( is_not_partial )
	{
		n_bmp_flip_onoff = n_posix_true;

		n_type_int     i = 0;
		n_type_gfx pxl_y = 0;
		n_posix_loop
		{

			n_mac_txtbox_draw_linenumber
			(
				font,
				i, scroll, n_txt->sy,
				(n_type_int) MIN( caret_fr.cch.y, caret_to.cch.y ),
				(n_type_int) MAX( caret_fr.cch.y, caret_to.cch.y ),
				o, o + pxl_y, linenumber_size.width, font_size.height,
				nscolor_back,
				nscolor_text,
				N_MAC_TXTBOX_DRAW_LINENUMBER_NONE
			);

			i++;

			pxl_y += font_size.height;
			if ( pxl_y > max_sy ) { break; }

		}

		n_bmp_flip_onoff = n_posix_false;
	}


	// [!] : Frame

	if ( is_not_partial )
	{
		//u32 outer = color_frame;
		//u32 inner = n_bmp_alpha_replace_pixel( color_bg, 0 );

		//n_bmp_ui_roundframe( &frame, 0,0,sx,sy, o + m, m, outer, inner );

		u32 color_edge[ 8 ] = {

			color_frame,
			color_frame,
			color_frame,
			color_frame,
			
			color_frame,
			color_frame,
			color_frame,
			color_frame,
		};

		n_bmp_ui_rectframe_drawedge( &canvas, 1, color_edge );


		// [!] : Fake Scroller

		CGFloat csy              = sy - ( o * 2 );
		CGFloat items_per_canvas = csy / font_size.height;
		CGFloat max_count        = (CGFloat) n_txt->sy;

		client_sy = sy;

//NSLog( @"%f %f", items_per_canvas, max_count );
		if ( trunc( items_per_canvas ) < max_count )
		{

			CGFloat correction = font_size.height * ( client_sy / ( max_count * font_size.height ) );
//NSLog( @"%f", correction );

			CGFloat page = max_count / items_per_canvas;

			n_type_gfx scrsx = 12;
			n_type_gfx scrsy = MAX( 12, trunc( csy / page ) );
			n_type_gfx scr_x = sx - o - scrsx;
			n_type_gfx scr_y = ceil( scroll * correction );
//NSLog( @"%f %f", scroll, font_size.height ); 


			// [!] : this is a kind of cheat
			scr_y = n_posix_minmax_n_type_gfx( o, csy - scrsy + o, scr_y );


			// [!] : for hit test
//scroller_rect = NSMakeRect( 0, 0, 0, 0 );
			scroller_rect_shaft = NSMakeRect( scr_x,     o, scrsx,   csy );
			scroller_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );


			u32 color = color_fg;

			n_bmp_flip_onoff = n_posix_true;

			u32 color_shaft = n_bmp_alpha_replace_pixel( color, 16 );
			n_bmp_roundrect( &canvas, scr_x,o, scrsx,csy, color_shaft, 50 );

//int alpha = 64;
//if ( thumb_is_hovered ) { alpha = 96; }
//u32 color_thumb = n_bmp_alpha_replace_pixel( color, alpha );


			int alpha_fade_bg;
			int alpha_fade_fg;
			if ( fade.color_fg == n_bmp_white )
			{
				alpha_fade_bg = 64;
				alpha_fade_fg = 96;
			} else {
				alpha_fade_bg = 96;
				alpha_fade_fg = 64;
			}
			int alpha = n_bmp_blend_channel( alpha_fade_bg, alpha_fade_fg, (double) fade.percent * 0.01 );
//NSLog( @"%d", fade.percent );

			u32 color_thumb = n_bmp_alpha_replace_pixel( color, alpha );
			n_bmp_roundrect( &canvas, scr_x,scr_y, scrsx,scrsy, color_thumb, 50 );

			n_bmp_flip_onoff = n_posix_false;
		}


		// [!] : Fake Caret

		if ( [self n_caret_on_screen] )
		{
			n_bmp_flip_onoff = n_posix_true;

			n_type_gfx  x = (n_type_gfx) caret_pt.x;
			n_type_gfx  y = (n_type_gfx) caret_pt.y;
			n_type_gfx sx = (n_type_gfx) 1;
			n_type_gfx sy = (n_type_gfx) font_size.height;

			n_bmp_box( &canvas, x,y,sx,sy, n_bmp_black+1 );

			n_bmp_flip_onoff = n_posix_false;
		}


		n_mac_image_nbmp_direct_draw( &canvas, &rect, TRUE );

	}


	redraw_fy = 0;
	redraw_ty = n_txt->sy;


NSLog( @"%d", (int) n_posix_tickcount() - tick );
}




- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );

	thumb_is_captured = FALSE;

	if ( thumb_is_hovered ) { return; }
	if ( shaft_is_hovered ) { return; }

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	pt               = [NSEvent mouseLocation];
	thumb_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, scroller_rect_thumb );
	shaft_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, scroller_rect_shaft );
//if ( thumb_is_hovered ) { NSLog( @"!" ); }

	NSPoint pt_cur   = n_mac_cursor_position_get( self );
	thumb_offset     = scroller_rect_thumb.origin.y - pt_cur.y;
//NSLog( @"%f : %f %f", thumb_offset, scroller_rect_thumb.origin.y, pt_cur.y );

	if ( thumb_is_hovered )
	{
		thumb_is_captured = TRUE;
	} else
	if ( shaft_is_hovered )
	{

		CGFloat sy               = [self frame].size.height;
		CGFloat csy              = sy - ( offset * 2 );
		CGFloat items_per_canvas = csy / font_size.height;

		if ( pt_cur.y < scroller_rect_thumb.origin.y )
		{
//NSLog( @"upper" );
			scroll -= items_per_canvas;
		} else {
//NSLog( @"lower" );
			scroll += items_per_canvas;
		}

		[self display];

	} else {

		if ( [theEvent clickCount] == 3 )
		{
			[self n_detect_tripleclick];
		} else
		if ( [theEvent clickCount] == 2 )
		{
			[self n_detect_doubleclick];
		} else {
			caret_fr = caret_to = [self n_detect_cursor];
		}

		thumb_is_hovered = n_posix_false;

		[self display];

	}

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog( @"mouseDragged" );

	CGPoint pt_cur = [NSEvent mouseLocation];

	CGFloat dy = pt.y - pt_cur.y;
//NSLog( @"%f %f", dy, [theEvent deltaY] );

	pt = pt_cur;

//scroll -= dy / font_size.height;

	if ( thumb_is_captured )
	{
//NSLog( @"1" ); 
		CGFloat max_count  = (CGFloat) n_txt->sy;
		CGFloat correction = client_sy / ( max_count * font_size.height );

		scroll += dy / ( font_size.height * correction );

	} else {

		if ( thumb_is_hovered ) { return; }
		if ( shaft_is_hovered ) { return; }

//NSLog( @"%lld", caret_fr.cch.y );
		caret_to = [self n_detect_cursor];
//NSLog( @"%@", n_mac_txtbox_copy( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y ) );

		if ( caret_fr.cch.x < caret_to.cch.x )
		{
			shift_selection_is_tail = TRUE;
		} else {
			shift_selection_is_tail = FALSE;
		}

		thumb_is_hovered = n_posix_false;

		[self display];

	}


	[self display];

}

- (void)scrollWheel:(NSEvent *)theEvent
{
//NSLog( @"%f", [theEvent deltaY] );

	if ( thumb_is_hovered ) { return; }
	if ( shaft_is_hovered ) { return; }


	scroll -= ( ( [theEvent deltaY] * 2 ) / font_size.height );
//NSLog( @"%f", scroll );

	[self display];
 
}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");
        return YES;
}

- (void)n_txtbox_input_method:(NSEvent*)event
{
//return;

	n_mac_txtbox_del( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y );
//return;

	[self n_caret_out_of_canvas_lr];
//return;

	n_posix_char *line_f = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
	n_posix_char *line_m = n_mac_nsstring2str( [event characters] );
	n_posix_char *line_t = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );


	line_f[ caret_fr.cch.x ] = N_STRING_CHAR_NUL;
	n_posix_sprintf_literal( line_t, "%s", &line_t[ caret_fr.cch.x ] );

	n_type_int    cch = n_posix_strlen( line_f ) + n_posix_strlen( line_m ) + n_posix_strlen( line_t );
	n_posix_char *s   = n_string_new( cch );
	n_posix_sprintf_literal( s, "%s%s%s", line_f, line_m, line_t );

	n_txt_mod( n_txt, n_focus, s );


	caret_fr.cch.x = caret_to.cch.x = n_posix_strlen( line_f ) + n_posix_strlen( line_m );

	caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
	(
		n_txt,
		n_focus,
		font,
		font_size,
		caret_fr.cch.x
	);


	n_string_free( s );


	n_string_free( line_f );
	n_string_free( line_m );
	n_string_free( line_t );


	[self n_undo:N_TXTBOX_UNDO_SUSPEND];

	[self display];

}

- (void)keyDown:(NSEvent*)event
{
//NSLog( @"Key Code = %d : Chars %@", event.keyCode, event.characters );

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_HOME:
	case N_MAC_KEYCODE_END:
	case N_MAC_KEYCODE_DELETE:
	case N_MAC_KEYCODE_PRTSCN:
	case N_MAC_KEYCODE_F1:
	case N_MAC_KEYCODE_F2:
	case N_MAC_KEYCODE_F3:
	case N_MAC_KEYCODE_F4:
	case N_MAC_KEYCODE_F5:
	case N_MAC_KEYCODE_F6:
	case N_MAC_KEYCODE_F7:
	case N_MAC_KEYCODE_F8:
	case N_MAC_KEYCODE_F9:
	case N_MAC_KEYCODE_F10:
	case N_MAC_KEYCODE_F12:

		//

	break;

	case N_MAC_KEYCODE_ARROW_UP :
	{
//NSLog( @"Up" );


		if ( event.modifierFlags & NSEventModifierFlagShift )
		{
		
			n_caret caret = caret_fr;

			[self n_detect_key_move:nil ud:-1 lr:0];

			caret_fr = caret;

		} else {

			[self n_detect_key_move:nil ud:-1 lr:0];

		}

		[self n_caret_out_of_canvas_ud];

		// [!] : [self display] paints gray on all contents(client) area
		//redraw_fy = caret_fr.cch.y;
		//redraw_ty = redraw_fy + 2;

		[self display];
	}
	break;

	case N_MAC_KEYCODE_ARROW_DOWN:
	{
//NSLog( @"Down" );

		if ( event.modifierFlags & NSEventModifierFlagShift )
		{

			n_caret caret = caret_fr;

			[self n_detect_key_move:nil ud:1 lr:0];

			caret_fr = caret;

		} else {

			[self n_detect_key_move:nil ud:1 lr:0];

		}

		[self n_caret_out_of_canvas_ud];

		[self display];
	}
	break;

	case N_MAC_KEYCODE_ARROW_LEFT:
	{
//NSLog( @"Left" );

		[self n_caret_out_of_canvas_lr];

		if ( event.modifierFlags & NSEventModifierFlagShift )
		{
			if ( caret_fr.cch.x == caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					shift_selection_is_tail = FALSE;
				}
				caret_to = [self n_detect_key_shift_selection:nil lr:-1 cch:caret_to.cch.x];
			} else
			if ( caret_fr.cch.x < caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					caret_to = [self n_detect_key_shift_selection:nil lr:-1 cch:caret_to.cch.x];
				} else {
					//
				}
			} else
			if ( caret_fr.cch.x > caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
				} else {
					caret_to = [self n_detect_key_shift_selection:nil lr:-1 cch:caret_to.cch.x];
				}
			}
		} else
		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			[self n_detect_doubleclick];
			caret_to = caret_fr;

			n_posix_char *line = n_txt_get( n_txt, n_focus );
			caret_to.cch.x = caret_fr.cch.x = n_mac_txtbox_caret_move( line, caret_to.cch.x, N_MAC_TXTBOX_CARET_MOVE_L );
		} else {
			[self n_detect_key_move:nil ud:0 lr:-1];
		}

		[self display];
	}
	break;

	case N_MAC_KEYCODE_ARROW_RIGHT:
	{
//NSLog( @"Right" );

		[self n_caret_out_of_canvas_lr];

		if ( event.modifierFlags & NSEventModifierFlagShift )
		{
			if ( caret_fr.cch.x == caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					//
				} else {
					shift_selection_is_tail = TRUE;
				}
				caret_to = [self n_detect_key_shift_selection:nil lr:1 cch:caret_to.cch.x];
			} else
			if ( caret_fr.cch.x < caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					caret_to = [self n_detect_key_shift_selection:nil lr:1 cch:caret_to.cch.x];
				} else {
					caret_fr = [self n_detect_key_shift_selection:nil lr:1 cch:caret_fr.cch.x];
				}
			} else
			if ( caret_fr.cch.x > caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					caret_to = [self n_detect_key_shift_selection:nil lr:1 cch:caret_to.cch.x];
				} else {
					caret_to = [self n_detect_key_shift_selection:nil lr:1 cch:caret_to.cch.x];
				}
			}
		} else
		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			[self n_detect_doubleclick];
			caret_fr = caret_to;
		} else {
			[self n_detect_key_move:nil ud:0 lr:1];
		}

		[self display];
	}
	break;

	case N_MAC_KEYCODE_ENTER:
	{

		CGFloat delta = ( caret_fr.cch.y - caret_to.cch.y );
//NSLog( @"%f", delta );

		n_mac_txtbox_del( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y );

		[self n_caret_out_of_canvas_lr];

		if ( delta != 0 )
		{
//NSLog( @"multi : %f", delta );

			if ( delta < 0 )
			{
				n_focus--;

				caret_to = caret_fr;
			} else {
				caret_fr = caret_to;
			}

		} else {
//NSLog( @"single" );
			n_posix_char *line = n_txt_get( n_txt, n_focus );
			n_posix_char *s    = n_string_carboncopy( line );

			n_txt_add( n_txt, n_focus + 1, &s[ caret_fr.cch.x ] );
			line[ caret_fr.cch.x ] = N_STRING_CHAR_NUL;

			n_string_free( s );


			n_focus++;
			caret_fr = caret_to = NonnonMakeCaret( 0, n_focus * font_size.height, 0, n_focus );


			CGFloat f = ( ( n_focus - scroll ) * font_size.height ) + font_size.height;
			CGFloat t = [self frame].size.height - ( offset * 2 );
			if ( f >= t ) { scroll += font_size.height; }

		}

		[self n_undo:N_TXTBOX_UNDO_SUSPEND];

		[self display];

	}
	break;

	case N_MAC_KEYCODE_BACKSPACE:
	{

		[self n_caret_out_of_canvas_lr];

		BOOL grow = ( caret_fr.cch.y < caret_to.cch.y );

		if ( n_mac_txtbox_del( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y ) )
		{
//NSLog( @"Backspace : deleted : %0.2f %lld %lld", n_focus, caret_fr.cch.y, caret_to.cch.y );

			n_focus = MIN( caret_fr.cch.y, caret_to.cch.y );

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				caret_fr.cch.x
			);

			[self display];

			break;
		}

		if ( caret_fr.cch.x == 0 )
		{

			if ( n_focus == 0 )
			{
				// [!] : for select all
				caret_fr = caret_to = NonnonMakeCaret( 0,0,0,0 );
				[self display];
				break;
			}


			n_posix_char *line_1 = n_txt_get( n_txt, n_focus - 1 );
			n_posix_char *line_2 = n_txt_get( n_txt, n_focus     );

			n_type_int    cch = n_posix_strlen( line_1 ) + n_posix_strlen( line_2 );
			n_posix_char *s   = n_string_new( cch );
			n_posix_sprintf_literal( s, "%s%s", line_1, line_2 );

			n_txt_del( n_txt, n_focus );
			n_txt_mod( n_txt, n_focus - 1, s );

			caret_fr.cch.x = caret_to.cch.x = n_posix_strlen( line_1 );

			n_focus--;

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				caret_fr.cch.x
			);

			n_string_free( s );

		} else {

			n_posix_char *line = n_txt_get( n_txt, n_focus );
			n_type_int     cch = n_mac_txtbox_caret_move( line, caret_fr.cch.x, N_MAC_TXTBOX_CARET_MOVE_L );

			n_posix_sprintf_literal( &line[ cch ], "%s", &line[ caret_fr.cch.x ] );

			if ( grow ) { n_focus = caret_fr.cch.y; }

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				cch
			);

		}

		[self n_undo:N_TXTBOX_UNDO_SUSPEND];

		[self display];

	}
	break;

	case N_MAC_KEYCODE_CUT:
	{

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{

			[self n_undo:N_TXTBOX_UNDO_RESET];

			NSString *s = n_mac_txtbox_copy( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y );

			NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
			[pasteboard clearContents];
			[pasteboard writeObjects:@[ s ]];
	
			n_mac_txtbox_del( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y );

			n_type_int cch = caret_fr.cch.x;

			if ( caret_fr.cch.y == caret_to.cch.y )
			{
				if ( caret_fr.pxl.x == caret_to.pxl.x )
				{
//NSLog( @"= : =" );
					//
				} else
				if ( caret_fr.pxl.x < caret_to.pxl.x )
				{
//NSLog( @"= : <" );
					cch = caret_fr.cch.x;
				} else
				//if ( caret_fr.pxl.x > caret_to.pxl.x )
				{
//NSLog( @"= : >" );
					cch = caret_to.cch.x;
				}
			} else
			if ( caret_fr.cch.y < caret_to.cch.y )
			{
//NSLog( @"<" );
				caret_to = caret_fr;
				cch      = caret_fr.cch.x;
				n_focus  = caret_fr.cch.y;

			} else
			if ( caret_fr.cch.y > caret_to.cch.y )
			{
//NSLog( @">" );
				caret_fr = caret_to;
				cch      = caret_to.cch.x;
				n_focus  = caret_to.cch.y;

			}

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				cch
			);

			[self display];

		} else {

			[self n_txtbox_input_method:event];

		}
	}
	break;

	case N_MAC_KEYCODE_COPY: 
	{
		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			NSString *s = n_mac_txtbox_copy( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y );
//NSLog( @"%@", s );
			NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
			[pasteboard clearContents];
			[pasteboard writeObjects:@[ s ]];
		} else {
			[self n_txtbox_input_method:event];
		}
	}
	break;

	case N_MAC_KEYCODE_PASTE:
	{

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{

			[self n_undo:N_TXTBOX_UNDO_RESET];


			n_mac_txtbox_del( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y );


			NSPasteboard *p = [NSPasteboard generalPasteboard];
			NSString     *s = [p stringForType:NSPasteboardTypeString];
			n_posix_char *c = n_mac_nsstring2str( s );
//NSLog( @"%@", s );
//NSLog( @"%s", c );
			n_txt t; n_txt_zero( &t ); n_txt_load_utf8_onmemory( &t, c, n_posix_strlen( c ) );
//NSLog( @"%lld", t.sy );

			if ( t.sy == 1 )
			{

				n_posix_char *line_f = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
				n_posix_char *line_m = n_string_carboncopy( n_txt_get(    &t,       0 ) );
				n_posix_char *line_t = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
				
				line_f[ caret_fr.cch.x ] = N_STRING_CHAR_NUL;
				sprintf( line_t, "%s", &line_t[ caret_fr.cch.x ] );
//NSLog( @"%s", line_f );
//NSLog( @"%s", line_t );

				n_type_int    cch = n_posix_strlen( line_f ) + n_posix_strlen( line_m ) + n_posix_strlen( line_t );
				n_posix_char *str = n_string_new( cch );
				n_posix_sprintf_literal( str, "%s%s%s", line_f, line_m, line_t );

				n_txt_mod( n_txt, n_focus, str );

				n_string_free( str );


				caret_fr.cch.x = caret_to.cch.x = caret_fr.cch.x + n_posix_strlen( line_m );

				caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
				(
					n_txt,
					n_focus,
					font,
					font_size,
					caret_fr.cch.x
				);


				n_string_free( line_f );
				n_string_free( line_m );
				n_string_free( line_t );

			} else {

				n_posix_char *line_f = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
				n_posix_char *line_t = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
				
				line_f[ caret_fr.cch.x ] = N_STRING_CHAR_NUL;
				sprintf( line_t, "%s", &line_t[ caret_fr.cch.x ] );
//NSLog( @"%s", line_f );

				{
					n_type_int    cch = n_posix_strlen( line_f ) + n_posix_strlen( n_txt_get( &t, 0 ) );
					n_posix_char *str = n_string_new( cch );

					n_posix_sprintf_literal( str, "%s%s", line_f, n_txt_get( &t, 0 ) );
					n_txt_mod_fast( n_txt, n_focus, str );
				}


				n_type_int i = 1;
				n_posix_loop
				{//break;
					if ( i >= t.sy ) { break; }
					
					n_txt_add( n_txt, n_focus + i, n_txt_get( &t, i ) );
					
					i++;
				}

				{
					n_type_int    cch = n_posix_strlen( n_txt_get( &t, i - 1 ) ) + n_posix_strlen( line_t );
					n_posix_char *str = n_string_new( cch );

					n_posix_sprintf_literal( str, "%s%s", n_txt_get( &t, i - 1 ), line_t );
					n_txt_mod_fast( n_txt, n_focus + i - 1, str );
				}


				n_focus = n_focus + i - 1;

				caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
				(
					n_txt,
					n_focus,
					font,
					font_size,
					n_posix_strlen( n_txt_get( &t, i - 1 ) )
				);


				n_string_free( line_f );
				n_string_free( line_t );

			}

			n_txt_free( &t );


			[self display];

		} else {

			[self n_txtbox_input_method:event];

		}

	}
	break;

	case N_MAC_KEYCODE_SELECT_ALL:
	{

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{

			caret_fr = NonnonMakeCaret( 0, 0, 0, 0 );

			n_caret caret = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_txt->sy - 1,
				font,
				font_size,
				n_posix_strlen( n_txt_get( n_txt, n_txt->sy - 1 ) )
			);

			caret_to = NonnonMakeCaret
			(
				caret.pxl.x,
				( (CGFloat) n_txt->sy - 1 ) * font_size.height,
				caret.cch.x,
				n_txt->sy - 1
			);

			[self display];

		} else {

			[self n_txtbox_input_method:event];

		}

	}
	break;

	case N_MAC_KEYCODE_UNDO:
	{

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{

			[self n_undo:N_TXTBOX_UNDO_RESTORE];

			[self display];

		} else {

			[self n_txtbox_input_method:event];

		}

	}
	break;

	case N_MAC_KEYCODE_SAVE:
	{

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			if ( n_txt_save_utf8( n_txt, n_mac_nsstring2str( path ) ) )
			{
//NSLog( @"n_txt_save_utf8() failed : %s", n_mac_nsstring2str( path ) );
			}
		} else {
			[self n_txtbox_input_method:event];
		}

	}
	break;

	default :

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			//
		} else {
			[self n_txtbox_input_method:event];
		}
	
	break;

	} // switch

}




-(NSDragOperation) draggingEntered:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingEntered" );

	// [!] : call when hovered

	return NSDragOperationCopy;
}

-(void) draggingExited:( id <NSDraggingInfo> )sender
{
//NSLog( @"draggingExited" );
}

-(BOOL) prepareForDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"prepareForDragOperation" );

	return YES;
}

-(BOOL) performDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"performDragOperation" );

	return YES;
}

-(void) concludeDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"concludeDragOperation" );

	//[self setStringValue:@""];

	NSPasteboard *pasteboard = [sender draggingPasteboard];
	NSString     *nsstring   = [[NSURL URLFromPasteboard:pasteboard] path];
	n_posix_char *str        = n_mac_nsstring2str( nsstring );

	n_txt_load_utf8( n_txt, str );
//NSLog( @"Unicode %d : Newline %d", n_txt->unicode, n_txt->newline );

	path = nsstring;

	[self n_reset];
	[self n_undo:N_TXTBOX_UNDO_RESET];

	[self display];


	n_string_free( str );

}

-(NSDragOperation) draggingUpdated:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingUpdated" );

	return NSDragOperationCopy;
}



/*
- (BOOL)hasMarkedText;
{
NSLog( @"hasMarkedText" );

	return NO;
}

- (NSRange)markedRange
{
NSLog( @"markedRange" );

	NSRange range = { NSNotFound, 0 };
	return range;
}

- (NSRange)selectedRange
{
NSLog( @"selectedRange" );

	NSRange range = { NSNotFound, 0 };
	return range;
}

- (void)setMarkedText:(id)string 
        selectedRange:(NSRange)selectedRange 
     replacementRange:(NSRange)replacementRange
{
NSLog( @"setMarkedText" );

	return;
}

- (void)unmarkText
{
NSLog( @"unmarkText" );

	return;
}

- (NSArray<NSAttributedStringKey> *)validAttributesForMarkedText
{
NSLog( @"validAttributesForMarkedText" );

	return [[NSArray alloc] init];
}

- (NSAttributedString *)attributedSubstringForProposedRange:(NSRange)range 
                                                actualRange:(NSRangePointer)actualRange
{
NSLog( @"attributedSubstringForProposedRange" );

	return nil;
}

- (void)insertText:(id)string 
  replacementRange:(NSRange)replacementRange
{
NSLog( @"replacementRange" );

	return;
}

- (NSUInteger)characterIndexForPoint:(NSPoint)point
{
NSLog( @"characterIndexForPoint" );

	return 0;
}

- (NSRect)firstRectForCharacterRange:(NSRange)range 
                         actualRange:(NSRangePointer)actualRange
{
NSLog( @"firstRectForCharacterRange" );

	// [!] : this is called when ON/OFF

	NSRect rect = NSMakeRect( 0,200,200,200 );
	return rect;
}

- (void)doCommandBySelector:(SEL)selector
{
NSLog( @"doCommandBySelector" );

	return;
}
*/

@end




#endif // _H_NONNON_MAC_NONNON_TXTBOX


