//
//  AppDelegate.m
//  CatPad for Mac
//
//  Created by のんのん on 2022/08/14.
//

#import "AppDelegate.h"



#include "../../nonnon/mac/n_txtbox.c"




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonTxtbox *n_txtbox;

@property n_txt n_txt;

@end




@implementation AppDelegate


@synthesize n_txt;




- (instancetype)init
{
	self = [super init];
	if ( self )
	{
		n_txt_zero( &n_txt ); n_txt_utf8_new( &n_txt );
	}
	
	return self;
}




- (void)awakeFromNib
{
	_n_txtbox.n_txt = &n_txt;

	[_window makeFirstResponder:_n_txtbox];

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}



- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


@end
