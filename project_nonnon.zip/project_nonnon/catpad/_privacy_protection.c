// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"




void
n_catpad_privacy_protection( void )
{

	HMODULE hmod = LoadLibrary( n_posix_literal( "kernel32.dll" ) );
	if ( hmod == NULL ) { return; }

#ifdef UNICODE
	FARPROC func = GetProcAddress( hmod, "GetEnvironmentVariableW" );
#else  // #ifdef UNICODE
	FARPROC func = GetProcAddress( hmod, "GetEnvironmentVariableA" );
#endif // #ifdef UNICODE

	if ( func != NULL )
	{
		n_posix_char str_f[ 1024 ]; n_posix_sprintf_literal( str_f, "%s", n_posix_literal( "UserProfile" ) );
		n_posix_char str_t[ 1024 ]; n_posix_sprintf_literal( str_t, "%s", N_STRING_EMPTY );

		func( str_f, str_t, 1024 );
//n_posix_debug_literal( "%s\n%s", str_f, str_t );

		n_posix_char target[ 1024 ];
		n_posix_sprintf_literal( target, "%s\\AppData\\Roaming\\Microsoft\\InputMethod\\Shared\\JpnIHDS.dat", str_t );
//n_posix_debug_literal( "%s", target );

		n_filer_remove( target );
	}

	FreeLibrary( hmod );


	return;
}


