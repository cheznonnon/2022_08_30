

// Link : -mthreads




typedef struct {

	bool   onoff;
	int    id;
	HANDLE func;

} n_thread;


int   tls_index = 0;
void* tls_data  = NULL;


int   value     = 0;
int   *ptr      = NULL;




unsigned __stdcall
n_thread_func( void* p )
{

	n_thread *t = p;


	if ( t->id == 1 )
	{
		tls_data = LocalAlloc( LPTR, sizeof( int ) ); TlsSetValue( tls_index, tls_data );
	}

	while( t->onoff )
	{

		n_posix_sleep( 1000 );

		n_posix_debug_literal
		(
			" ID    %d \n "
			" Value %d \n "
			" Ptr   %d \n "
			" Tls   %d \n ",
			t->id,
			value,
			*ptr,
			TlsGetValue( tls_index )
		);
 
		if ( t->id == 1 ) { value++; (*ptr)++; }
		if ( t->id == 2 ) { value--; (*ptr)--; }

	}


	if ( t->id == 1 )
	{
		LocalFree( tls_data );
	}


	n_posix_debug_literal( " _endthreadex() : ID %d ", t->id );


	_endthreadex( 0 );
	return 0;
} 

#define n_thread_zero( t ) n_memory_zero( t, sizeof( n_thread ) )

void
n_thread_init( n_thread *t, void *func, int id )
{

	t->onoff = true;
	t->id    = id;
	t->func  = (HANDLE) _beginthreadex( NULL, 0, func, (void*) t, 0, NULL );


	return;
}

void
n_thread_exit( n_thread *t )
{

	t->onoff = false;
	WaitForSingleObject( t->func, INFINITE );

	CloseHandle( t->func );
	n_thread_zero( t );


	return;
}

void
n_thread_test( void )
{

	value = 10;
	ptr   = malloc( sizeof( int ) ); *ptr = 20;


	tls_index = TlsAlloc();


	n_thread t1; n_thread_zero( &t1 );
	n_thread t2; n_thread_zero( &t2 );

	n_thread_init( &t1, n_thread_func, 1 );
	n_thread_init( &t2, n_thread_func, 2 );


	CRITICAL_SECTION cs; InitializeCriticalSection( &cs );

	while( 1 )
	{

		if ( n_win_is_input( VK_CONTROL ) ) { break; }

		n_posix_sleep( 1000 );

		EnterCriticalSection( &cs );
		value  *= 2;
		(*ptr) *= 2;
		LeaveCriticalSection( &cs );

	}

	DeleteCriticalSection( &cs );

	n_thread_exit( &t1 );
	n_thread_exit( &t2 );


	TlsFree( tls_index );


	free( ptr );


n_posix_debug_literal( "End" );
	return;
}

