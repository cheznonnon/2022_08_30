// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC_IMAGE
#define _H_NONNON_MAC_IMAGE




#import <Cocoa/Cocoa.h>


#include "../neutral/bmp/all.c"
#include "../neutral/png.c"


#include "./_mac.c"




void
n_bmp_mac_color( n_bmp *bmp )
{

	// [!] : format
	//
	//	ABGR
	//	upside down


	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{
		u32 color;
		n_bmp_ptr_get_fast( bmp, x,y, &color );

		color = n_bmp_argb
		(
			n_bmp_a( color ),
			n_bmp_b( color ),
			n_bmp_g( color ),
			n_bmp_r( color )
		);

		n_bmp_ptr_set_fast( bmp, x,y,  color );

		x++;
		if ( x >= N_BMP_SX( bmp ) )
		{

			x = 0;

			y++;
			if ( y >= N_BMP_SY( bmp ) ) { break; }
		}
	}


	return;
}

void
n_bmp_mac( n_bmp *bmp )
{

	n_bmp_mac_color( bmp );

	n_bmp_flush_mirror( bmp, N_BMP_MIRROR_UPSIDE_DOWN );


	return;
}




#define n_bmp_rgb_mac( r, g, b ) n_bmp_rgb( b, g, r )

#define n_bmp_argb_mac( a, r, g, b ) n_bmp_argb( a, b, g, r )

#define n_bmp_color_mac( c ) n_bmp_argb( n_bmp_a( c ), n_bmp_b( c ), n_bmp_g( c ), n_bmp_r( c ) )

#define n_mac_nscolor_argb( a, r, g, b ) [NSColor colorWithSRGBRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)/255.0]

#define n_mac_argb2nscolor( c ) n_mac_nscolor_argb( n_bmp_a( c ), n_bmp_r( c ), n_bmp_g( c ), n_bmp_b( c ) )

u32
n_mac_nscolor2argb( NSColor *nscolor )
{

	CIColor *cicolor = [[CIColor alloc] initWithColor:nscolor];

	int a = (int) ( cicolor.alpha * 255.0 );
	int r = (int) ( cicolor.red   * 255.0 );
	int g = (int) ( cicolor.green * 255.0 );
	int b = (int) ( cicolor.blue  * 255.0 );

//NSLog( @"%f %f %f %f", cicolor.alpha, cicolor.red, cicolor.green, cicolor.blue );


	return n_bmp_argb( a,r,g,b );
}




NSPoint
n_mac_image_position_flip( const n_bmp *bmp, NSPoint pt )
{

	pt.y = N_BMP_SY( bmp ) - 1 - pt.y;

	return pt;
}

NSImage*
n_mac_image_nbmp2nsimage( const n_bmp *bmp )
{

	// [Needed] : a space in each line is needed (maybe)

	NSBitmapImageRep *n_rep = [
		[NSBitmapImageRep alloc]
		 initWithBitmapDataPlanes : (void*) &N_BMP_PTR( bmp )
		 pixelsWide               : N_BMP_SX( bmp )
		 pixelsHigh               : N_BMP_SY( bmp )
		 bitsPerSample            : 8
		 samplesPerPixel          : 4
		 hasAlpha                 : YES
		 isPlanar                 : NO
		 colorSpaceName           : NSCalibratedRGBColorSpace
		 bytesPerRow              : (int) N_BMP_SX( bmp ) * 4
		 bitsPerPixel             : 32
	];

//if ( n_rep == nil ) { NSLog( @"NSBitmapImageRep : nil" ); }


	NSImage *n_nsimage = [NSImage.alloc initWithSize:n_rep.size];
	[n_nsimage addRepresentation:n_rep];

//if ( n_nsimage == nil ) { NSLog( @"NSImage : nil" ); }


	return n_nsimage;
}

void
n_mac_image_nsimage2nbmp( NSImage *image, n_bmp *bmp )
{

	NSData *data = [image TIFFRepresentation];

	n_type_gfx sx = (n_type_gfx) image.size.width;
	n_type_gfx sy = (n_type_gfx) image.size.height;

	// [x] : ARC does not working at this section
	free( N_BMP_PTR( bmp ) ); N_BMP_PTR( bmp ) = NULL;

	n_bmp_new( bmp, sx, sy );

	n_memory_copy( [data bytes], N_BMP_PTR( bmp ), N_BMP_SIZE( bmp ) );


	// [!] : do when needed manually
	//n_bmp_mac( bmp );


	return;
}

n_posix_bool
n_mac_image_path2nbmp( n_posix_char *path, n_bmp *bmp )
{

	if ( n_posix_stat_is_dir( path ) ) { return n_posix_true; }

	if (
		( n_png_png2bmp( path, bmp ) )
		&&
		( n_bmp_load( bmp, path ) )
	)
	{
		NSImage *img = [ [NSImage alloc] initByReferencingFile:n_mac_str2nsstring( path ) ];
		n_mac_image_nsimage2nbmp( img, bmp );
	} else {
		n_bmp_mac( bmp );
	}


	return n_posix_false;
}

void
n_mac_image_nbmp_direct_draw( const n_bmp *bmp, NSRect *rect, n_posix_bool flip )
{

//static u32 tick_prv = 0;

/*
	// [!] : slowest

	NSDrawBitmap
	(
		NSMakeRect( 0,0, N_BMP_SX( bmp ),N_BMP_SY( bmp ) ),
		N_BMP_SX( bmp ),
		N_BMP_SY( bmp ),
		8,
		4,
		0,
		(int) N_BMP_SX( bmp ) * 4,
		NO,
		YES,
		NSCalibratedRGBColorSpace,
		(void*) &N_BMP_PTR( bmp )
	);
*/

	NSImage *img = n_mac_image_nbmp2nsimage( bmp );


	// [!] : slower than CGContextDrawImage()

	//[img drawInRect:*rect];


	// [!] : fastest

	NSGraphicsContext *context = [NSGraphicsContext currentContext];
	CGImageRef         ref     = [img CGImageForProposedRect:rect context:context hints:nil];
	CGContextRef       cg_ctx  = [context CGContext];

	if ( flip )
	{
		CGContextTranslateCTM( cg_ctx, 0, img.size.height );
		CGContextScaleCTM( cg_ctx, 1.0, -1.0 );
	}

	CGContextDrawImage( cg_ctx, NSRectToCGRect( *rect ), ref );


//u32 tick_cur = n_posix_tickcount();

//NSLog( @"%d", (int) tick_cur - tick_prv );

//tick_prv = tick_cur;


	return;
}




CGSize
n_mac_image_text_pixelsize( NSString *text, NSFont *font )
{

	// [x] : buggy : this module will report insufficient width
	//
	//	make width larger than reported width

	CGSize size = CGSizeZero;

	CGRect frame = [text
		 boundingRectWithSize:CGSizeMake( CGFLOAT_MAX, CGFLOAT_MAX )
		 options:NSStringDrawingUsesLineFragmentOrigin
		 attributes:@{ NSFontAttributeName:font }
		 context:nil
	];

	// [!] : +1 : prevent wordwrap
	size = CGSizeMake( frame.size.width + 1, frame.size.height + 1 );


	return size;
}

void
n_mac_image_text_native
(
	NSImage  *image,
	NSString *text,
	NSFont   *font,
	NSColor  *color,
	CGFloat   ox,
	CGFloat   oy
)
{

	CGFloat isx = image.size.width;
	CGFloat isy = image.size.height;

	CGSize size = n_mac_image_text_pixelsize( text, font );

	NSRect rect = {
		{
			( ( isx - size.width  ) / 2 ) + ox,
			( ( isy - size.height ) / 2 ) + oy
		},
		{ size.width, size.height }
	};


	NSMutableDictionary *attr = [NSMutableDictionary dictionary];

	[attr setObject:font  forKey:NSFontAttributeName           ];
	[attr setObject:color forKey:NSForegroundColorAttributeName];


	[image lockFocus];

	[text drawInRect:rect withAttributes:attr];

	[image unlockFocus];


	return;
}

#define N_MAC_IMAGE_TEXT_NONE    ( 0 << 0 )
#define N_MAC_IMAGE_TEXT_CENTER  ( 1 << 0 )
#define N_MAC_IMAGE_TEXT_CONTOUR ( 1 << 1 )
#define N_MAC_IMAGE_TEXT_SINK    ( 1 << 2 )
#define N_MAC_IMAGE_TEXT_MAC     ( 1 << 3 )

void
n_mac_image_text
(
	n_bmp    *bmp,
	NSString *text,
	NSFont   *font,
	u32       color_text,
	u32       color_effect,
	CGFloat   parameter_effect,
	CGFloat   ox,
	CGFloat   oy,
	int       mode
)
{

	CGSize size = n_mac_image_text_pixelsize( text, font );

	CGFloat isx = size.width;
	CGFloat isy = size.height;

	// [!] : *2 : more buffer is needed
	n_bmp bmp_text; n_bmp_zero( &bmp_text ); n_bmp_new( &bmp_text, isx * 2, isy );
//n_bmp_flush( &bmp_text, n_bmp_white );

	NSImage *image = n_mac_image_nbmp2nsimage( &bmp_text );

	[image lockFocus];

	NSMutableDictionary *attr = [NSMutableDictionary dictionary];

	[attr setObject:font                 forKey:NSFontAttributeName           ];
	[attr setObject:[NSColor whiteColor] forKey:NSForegroundColorAttributeName];

	NSRect rect = NSMakeRect( 0, 0, isx, isy );
	[text drawInRect:rect withAttributes:attr];

	[image unlockFocus];

	// [x] : ARC does not working at this section
	free( N_BMP_PTR( &bmp_text ) ); N_BMP_PTR( &bmp_text ) = NULL;

	n_mac_image_nsimage2nbmp( image, &bmp_text );

	// [x] : bug : garbage pixel will appear
	if ( n_bmp_flip_onoff )
	{
		n_bmp_box( &bmp_text, 0,    0, 2,2, n_bmp_black );
	} else {
		n_bmp_box( &bmp_text, 0,isy-2, 2,2, n_bmp_black );
	}
//n_bmp_save( &bmp_text, "ret.bmp" );

	if ( mode & N_MAC_IMAGE_TEXT_MAC )
	{
		n_bmp_mac( &bmp_text );
	}

	if ( mode & N_MAC_IMAGE_TEXT_CENTER )
	{
		ox += ( N_BMP_SX( bmp ) - isx ) / 2;
		oy += ( N_BMP_SY( bmp ) - isy ) / 2;
	}

	if ( mode & N_MAC_IMAGE_TEXT_CONTOUR )
	{

		n_type_gfx prm = parameter_effect;

		n_type_gfx x = -prm;
		n_type_gfx y = -prm;
		n_posix_loop
		{

			n_bmp_rasterizer( &bmp_text, bmp, ox+ x, oy + y, color_effect, n_posix_false );

			x++;
			if ( x >= ( prm + 1 ) )
			{
				x = -prm;
				y++;
				if ( y >= ( prm + 1 ) ) { break; }
			}
		}
	} else
	if ( mode & N_MAC_IMAGE_TEXT_SINK )
	{
	
		u32 tl = n_bmp_rgb(   1,  1,  1 );
		u32 dr = n_bmp_rgb( 255,255,255 );

		n_bmp_rasterizer( &bmp_text, bmp, ox+1, oy-1, dr, n_posix_false );
		n_bmp_rasterizer( &bmp_text, bmp, ox-1, oy+1, tl, n_posix_false );

	}


	//n_bmp_fastcopy( &bmp_text, bmp, 0,0,isx,isy, ox,oy );
	n_bmp_rasterizer( &bmp_text, bmp, ox, oy, color_text, n_posix_false );


	n_bmp_free( &bmp_text );


	return;
}




void
n_mac_image_rc_load_bmp( NSString *name, n_bmp *bmp )
{

	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:name ofType:@"bmp"];

	n_posix_bool ret = n_bmp_load( bmp, n_mac_nsstring2str( path ) );
	if ( ret == n_posix_false )
	{
		// [!] : do when needed manually
		//n_bmp_mac( bmp );
	}


	return;
}




#endif // _H_NONNON_MAC_IMAGE


