// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
n_posix_char*
n_mac_txtbox_character
(
		//BOOL      is_monospace,
	      NSFont     *nsfont,
	      CGSize      nsfont_size,
	const u8         *str,
	      n_type_int  index,
	      CGSize     *ret_size,
	      n_type_int *ret_cch,
	      n_type_int *ret_tab
)
{

	// [ Mechanism ]
	//
	//	call this module from begining of a string
	//
	//	index    : element counter
	//	ret_size : pixel metrics of returned string
	//	ret_cch  : character count
	//	ret_tab  : tabbed character count


	static n_posix_char character[ 20 ];

	if ( ret_size == NULL ) { n_string_truncate( character ); }


	n_type_int _index = 0;
	n_type_int _tab   = 0;
	n_type_int _width = 1;

	if ( str[ index ] == N_STRING_CHAR_NUL )
	{

		n_string_truncate( character );

	} else
	if ( ( str[ index ] == N_STRING_CHAR_TAB )&&( ret_tab != NULL ) )
	{

		n_type_int tabstop = 8;
		if ( tabstop <= 0 ) { tabstop = 8; }

		const n_type_int tab = tabstop - ( (*ret_tab) % tabstop );

		if ( ret_size != NULL )
		{
			n_string_padding  ( character, N_STRING_CHAR_SPACE, tab );
			n_string_terminate( character, tab );
		}

		_index = 1;
		_tab   = tab;

	} else {

		n_type_int byte;
		if ( str[ index ] >= 0xf0 )
		{
			byte = 4;
		} else
		if ( str[ index ] >= 0xe0 )
		{
			byte = 3; _width = 2;
		} else
		if ( str[ index ] >= 0xc0 )
		{
			byte = 2;
		} else {
			byte = 1;
		}

		n_type_int i = 0;
		n_posix_loop
		{
			if ( ret_size != NULL ) { character[ i ] = str[ index + i ]; }

			i++;
			if ( i >= byte ) { break; }
		}

		if ( ret_size != NULL ) { character[ i ] = N_STRING_CHAR_NUL; }

		_index = byte;
		_tab   = 1;

	}

	if ( ret_size != NULL )
	{
		if ( nsfont.fixedPitch )
		{
			CGFloat kaku = nsfont_size.width * _width;
			CGFloat tabs = nsfont_size.width * _tab  ;

			(*ret_size) = NSMakeSize( MAX( kaku, tabs ), nsfont_size.height );
		} else {
			NSString *nsstr = n_mac_str2nsstring( character );
			(*ret_size) = n_mac_image_text_pixelsize( nsstr, nsfont );
		}
	}
	if ( ret_cch  != NULL ) { (*ret_cch)  = _index; }
	if ( ret_tab  != NULL ) { (*ret_tab) += _tab  ; }


	return character;
}

