// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_MAC_TXTBOX_CARET_MOVE_L ( 1 )
#define N_MAC_TXTBOX_CARET_MOVE_R ( 2 )

n_type_int
n_mac_txtbox_caret_move( n_posix_char *str_arg, n_type_int cch, int movement )
{

	if ( cch < 0 ) { return cch; }

	u8 *str = (u8*) str_arg;

	if ( movement == N_MAC_TXTBOX_CARET_MOVE_L )
	{

		if ( cch == 0 ) { return cch; }

		n_posix_loop
		{

			cch--;
			if ( cch <= 0 ) { break; }

			if ( str[ cch ] >= 0xf0 )
			{
				break;
			} else
			if ( str[ cch ] >= 0xe0 )
			{
				break;
			} else
			if ( str[ cch ] >= 0xc0 )
			{
				break;
			} else
			if ( str[ cch ] <= 127 )
			{
				break;
			}

		}

	} else
	if ( movement == N_MAC_TXTBOX_CARET_MOVE_R )
	{

		n_posix_loop
		{

			if ( str[ cch ] == 0x00 ) { break; }
			cch++;

			if ( str[ cch ] >= 0xf0 )
			{
				break;
			} else
			if ( str[ cch ] >= 0xe0 )
			{
				break;
			} else
			if ( str[ cch ] >= 0xc0 )
			{
				break;
			} else
			if ( str[ cch ] <= 127 )
			{
				break;
			}

		}

	}


	return cch;
}

