// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_txt_utf8_new( n_txt *txt )
{

	int newline = txt->newline;
	int unicode = txt->unicode;

	n_txt_new( txt );

	txt->newline = newline;
	txt->unicode = unicode;


	return;
}

#define n_txt_load_utf8(          v, fname        ) n_txt_load_utf8_internal( v, (void*) fname,    0, n_posix_true  )
#define n_txt_load_utf8_onmemory( v, stream, byte ) n_txt_load_utf8_internal( v,        stream, byte, n_posix_false )

// internal
n_posix_bool
n_txt_load_utf8_internal( n_txt *txt, void *stream, n_type_int byte, n_posix_bool is_file )
{

	// [!] : load_onmemory() : don't free "stream" after calling this function


	if ( txt == NULL ) { return n_posix_true; }


	n_type_int bom_offset = 0;


	txt->unicode = N_TXT_UNICODE_UTF;

	if ( is_file )
	{

		FILE *fp = n_posix_fopen_read( stream );
		if ( fp == NULL ) { return n_posix_true; }

		byte = n_posix_stat_size( stream );


		// [!] : remember original spec

		u8 sniffer[ 3 ]; n_posix_fread( sniffer, 3, 1, fp );

		if ( ( byte >= 3 )&&( n_unicode_bom_is_utf8    ( sniffer, 3 ) ) )
		{
			txt->unicode = N_TXT_UNICODE_UTF;
			n_posix_fseek( fp, 3, SEEK_SET );
			byte -= 3;
		} else
		if ( ( byte >= 2 )&&( n_unicode_bom_is_utf16_le( sniffer, 2 ) ) )
		{
			txt->unicode = N_TXT_UNICODE_LIL;
			n_posix_fseek( fp, 2, SEEK_SET );
			byte -= 2;
		} else
		if ( ( byte >= 2 )&&( n_unicode_bom_is_utf16_be( sniffer, 2 ) ) )
		{
			txt->unicode = N_TXT_UNICODE_BIG;
			n_posix_fseek( fp, 2, SEEK_SET );
			byte -= 2;
		} else {
			n_posix_fseek( fp, 0, SEEK_SET );
		}


		stream = n_memory_new( byte );
		n_posix_fread( stream, byte, 1, fp );

		n_posix_fclose( fp );

	} else {

		bom_offset = 0;

	}


	// Decoder

	if ( txt->unicode == N_TXT_UNICODE_UTF )
	{

		//

	} else
	if ( txt->unicode == N_TXT_UNICODE_NIL )
	{

		// [!] : curretly handled as UTF-8

	} else {

		char *ptr = n_unicode_alloccopy( &byte, stream );

		if ( txt->unicode == N_TXT_UNICODE_BIG )
		{
			n_unicode_endianness( ptr, byte );
		}

		n_unicode_utf8_encode( ptr, byte );


		n_memory_free( stream );

		byte   = strlen( ptr );
		stream = ptr;

	}


	txt->newline = n_txt_newline_check( stream, byte );


//NSLog( @"%lld %s", byte, stream );

	n_vector_load_onmemory( (n_vector*) txt, stream, byte );


//n_posix_debug( txt->stream );


	return n_posix_false;
}

n_posix_bool
n_txt_save_utf8( n_txt *txt, const n_posix_char *fname )
{

	if ( n_txt_error( txt ) ) { return n_posix_true; }


	if ( txt->readonly ) { return n_posix_true; }


	n_txt_stream( txt );


	// Encoder

	n_posix_bool  is_allocated;
	char         *ptr;
	n_type_int    byte;

//NSLog( @"%d", txt->unicode );

	if ( ( txt->unicode == N_TXT_UNICODE_LIL )||( txt->unicode == N_TXT_UNICODE_BIG ) )
	{

		is_allocated = n_posix_true;

		byte = txt->byte;
		ptr  = n_unicode_alloccopy( &byte, txt->stream );


		// [!] : n_posix_false is returned always

		n_posix_bool lost = n_unicode_codec_char2wchar( ptr, byte );
		if ( lost ) { n_memory_free( ptr ); return n_posix_true; }


		byte = wcslen( (wchar_t*) ptr ) * sizeof( wchar_t );

//MessageBoxW( NULL, ptr_t, L"DEBUG", 0 );

		if ( txt->unicode == N_TXT_UNICODE_BIG )
		{

			n_unicode_endianness( ptr, byte );

		}

	} else
	//if ( txt->unicode == N_TXT_UNICODE_UTF )
	{

		// [!] : currently non-unicode formats are handled as UTF-8 always

		is_allocated = n_posix_false;

		byte = txt->byte;
		ptr  = txt->stream;

	}


	n_posix_bool ret = n_posix_false;


	FILE *fp = n_posix_fopen_write( fname );
	if ( fp == NULL )
	{
		ret = n_posix_true;
	} else {
		n_posix_fwrite( ptr, byte, 1, fp );
	}
	n_posix_fclose( fp );


	if ( is_allocated ) { n_memory_free( ptr ); }


	return ret;
}

