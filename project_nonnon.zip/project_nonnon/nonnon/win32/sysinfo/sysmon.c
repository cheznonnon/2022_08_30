// Nonnon Win32 System Information
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Mechanism]
//
//	you cannot get CPU ratio in Win9x without sysmon.exe
//	sysmon.exe is an optional file, not always installed
//	if not exist then 100% is returned




#ifndef _H_NONNON_WIN32_SYSINFO_SYSMON
#define _H_NONNON_WIN32_SYSINFO_SYSMON




#include "./processlist.c"


#include "../win.c"




#define N_SYSINFO_SYSMON "sysmon.exe"




void
n_sysinfo_sysmon_init( void )
{

	if ( n_posix_false == n_sysinfo_version_9x() ) { return; }


	n_win_exec_literal( N_SYSINFO_SYSMON, SW_HIDE );


	return;
}

// internal
void
n_sysinfo_sysmon_exit( void )
{

	if ( n_posix_false == n_sysinfo_version_9x() ) { return; }


	n_sysinfo_processlist p;
	n_sysinfo_processlist_zero( &p );
	n_sysinfo_processlist_make( &p );


	n_type_int i = 0;
	n_posix_loop
	{
//n_posix_debug_literal( " %s ", p.exe.line[ i ] );

		n_posix_char *sysmon = n_string_path_name_new( p.exe.line[ i ] );

		if ( n_string_is_same_literal( N_SYSINFO_SYSMON, sysmon ) )
		{
			HWND h = (HWND) n_posix_atoi( p.hwnd.line[ i ] );
			if ( n_posix_false == IsWindowVisible( h ) )
			{
				n_string_path_free( sysmon );

				n_win_message_send( h, WM_CLOSE, 0,0 );

				break;
			}
		}

		n_string_path_free( sysmon );


		i++;
		if ( i >= p.exe.sy ) { break; }
	}


	n_sysinfo_processlist_exit( &p );


	return;
}


#endif // _H_NONNON_WIN32_SYSINFO_SYSMON

