// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -loleaut32


// [Limitation]
//
//	[ Supported Format ]
//
//	GIF/JPG	




#ifndef _H_NONNON_WIN32_OLE_IPICTURE
#define _H_NONNON_WIN32_OLE_IPICTURE




#include "../../neutral/bmp.c"

#include "../win/bitmap.c"




#include <olectl.h>
//#include <shlwapi.h>




#define n_IPicture_load( name, bmp ) n_IPicture_load_shrink( name, bmp, 0, 0 )

n_posix_bool
n_IPicture_load_shrink( const n_posix_char *name, n_bmp *bmp, n_type_gfx ret_sx, n_type_gfx ret_sy )
{

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_IPicture_load_shrink()" );


	const GUID guid_IID_IPicture = { 0x7BF80980,0xBF32,0x101A,{ 0x8B,0xBB, 0x00,0xAA,0x00,0x30,0x0C,0xAB } };


	// [!] : sniffer : prevent hangup with too large files
	//
	//	47 49 46 38 39 61
	//	 G  I  F  8  9  a
	//
	//	ff d8 ff e0 00 10 4a 46 49 46 00
	//	 .  .  .  .  .  .  J  F  I  F  .
	//
	//	ff d8 ff e1 21 09 45 78 69 66 00
	//	 .  .  .  .  !  .  E  x  i  f  .


	u8     sniffer_gif [] = { 0x47, 0x49, 0x46, 0x38, 0x39, 0x61 };
	u8     sniffer_jpg [] = { 0xff, 0xd8, 0xff };

	n_posix_structstat_size_t sniffer_byte = 6;

	if ( sniffer_byte > n_posix_stat_size( name ) )
	{
		hmutex = n_win_mutex_exit( hmutex );
		return n_posix_true;
	}


	FILE *fp = n_posix_fopen_read( name );
	if ( fp == NULL )
	{
		hmutex = n_win_mutex_exit( hmutex );
		return n_posix_true;
	}


	u8 sniffer_ptr[ 6 ];
	n_posix_fread( sniffer_ptr, sniffer_byte, 1, fp );


	if (
		( n_posix_false == n_memory_is_same( sniffer_ptr, sniffer_gif, 6 ) )
		&&
		( n_posix_false == n_memory_is_same( sniffer_ptr, sniffer_jpg, 3 ) )
	)
	{
//n_posix_debug_literal( "1" );

		n_posix_fclose( fp );

		hmutex = n_win_mutex_exit( hmutex );

		return n_posix_true;
	}
//n_posix_debug_literal( "2" ); n_posix_fclose( fp ); return n_posix_true;


	n_type_int  b = n_posix_stat_size( name );
	HGLOBAL     h = GlobalAlloc( GPTR, b );
	u8         *p = GlobalLock( h );

	n_posix_fseek( fp, 0, SEEK_SET );
	n_posix_fread( p, b, 1, fp );

	GlobalUnlock( h );


	n_posix_fclose( fp );


	HRESULT hr;


	IStream *n_IStream = NULL;
	hr = CreateStreamOnHGlobal( h, TRUE, &n_IStream );
	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "CreateStreamOnHGlobal()", 0 );

		hmutex = n_win_mutex_exit( hmutex );

		return n_posix_true;
	}


/*
	// [!] : Win98 or later only : Link -lshlwapi

	IStream *n_IStream = NULL;
	hr = SHCreateStreamOnFile( name, STGM_READ, &n_IStream );
	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "SHCreateStreamOnFile()", 0 );

		hmutex = n_win_mutex_exit( hmutex );

		return n_posix_true;
	}
*/

	IPicture *n_IPicture = NULL;
	hr = OleLoadPicture( n_IStream, 0, TRUE, &guid_IID_IPicture, (void*) &n_IPicture );
	if ( FAILED( hr ) )
	{
//if ( hr == E_NOINTERFACE ) { n_posix_debug_literal( "OleLoadPicture() : E_NOINTERFACE", 0 ); }
//if ( hr == E_POINTER     ) { n_posix_debug_literal( "OleLoadPicture() : E_POINTER",     0 ); }

		n_IStream->lpVtbl->Release( n_IStream );

		hmutex = n_win_mutex_exit( hmutex );

		return n_posix_true;
	}



	SHORT pictype;
	n_IPicture->lpVtbl->get_Type( n_IPicture, &pictype );
//n_posix_debug_literal( "%d", pictype );

	if ( pictype != 1 )
	{

		n_IPicture->lpVtbl->Release( n_IPicture );
		n_IStream->lpVtbl->Release( n_IStream );

		hmutex = n_win_mutex_exit( hmutex );

		return n_posix_true;
	}


	HDC hdc = GetDC( NULL );


	// [!] : OLE_*SIZE_HIMETRIC is "long"

	OLE_XSIZE_HIMETRIC ole_sx = 0;
	OLE_YSIZE_HIMETRIC ole_sy = 0;

	n_IPicture->lpVtbl->get_Width ( n_IPicture, &ole_sx );
	n_IPicture->lpVtbl->get_Height( n_IPicture, &ole_sy );

        n_type_gfx sx = MulDiv( ole_sx, GetDeviceCaps( hdc, LOGPIXELSX ), 2540 );
        n_type_gfx sy = MulDiv( ole_sy, GetDeviceCaps( hdc, LOGPIXELSY ), 2540 );

	if ( ( ret_sx > 0 )&&( ret_sy > 0 ) ) 
	{
		n_type_gfx ret_max = n_posix_max_n_type_gfx( ret_sx, ret_sy );
		n_type_gfx bmp_max = n_posix_max_n_type_gfx(     sx,     sy );
		n_type_gfx n       = bmp_max / ret_max;

		if ( n > 0 )
		{
			sx /= n;
			sy /= n;
		}

	}
//n_posix_debug_literal( "%d %d", sx, sy );


	n_bmp_free( bmp );
	n_bmp_1st_fast( bmp, sx,sy );

	BITMAPINFO bi  = { N_BMP_INFOH( bmp ), { { 0,0,0,0 } } };
	HDC hdc_compat = CreateCompatibleDC( hdc );
	HBITMAP hbmp   = CreateDIBitmap( hdc, &bi.bmiHeader, CBM_INIT, N_BMP_PTR( bmp ), &bi, DIB_RGB_COLORS );
	HBITMAP p_hbmp = SelectObject( hdc_compat, hbmp );


	{

		// [!] : Tricky : source position and size is inaccurate
		//
		//	{ 0, 0, ole_sx, ole_sy } doesn't render the last line

		n_type_gfx fx  = 0;
		n_type_gfx fy  = ole_sy;
		n_type_gfx fsx = ole_sx;
		n_type_gfx fsy = ole_sy * -1;
		n_type_gfx tx  = 0;
		n_type_gfx ty  = 0;
		n_type_gfx tsx = sx;
		n_type_gfx tsy = sy;

		n_IPicture->lpVtbl->Render( n_IPicture, hdc_compat, tx,ty,tsx,tsy, fx,fy,fsx,fsy, NULL );

	}


	SelectObject( hdc_compat, p_hbmp );
	GetDIBits( hdc_compat, hbmp, 0,sy, N_BMP_PTR( bmp ), &bi, DIB_RGB_COLORS );
	n_win_bitmap_exit( hbmp );
	DeleteDC( hdc_compat );


	ReleaseDC( NULL, hdc );


	n_IPicture->lpVtbl->Release( n_IPicture );

	n_IStream->lpVtbl->Release( n_IStream );


	if ( N_BMP_ALPHA_CHANNEL_VISIBLE == 255 ) { n_bmp_alpha_visible( bmp ); }


	hmutex = n_win_mutex_exit( hmutex );


	return n_posix_false;
}


#endif // _H_NONNON_WIN32_OLE_IPICTURE

