// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_FLUENT_UI
#define _H_NONNON_WIN32_WIN_FLUENT_UI




#include "../../game/progressbar.c"

#include "../../neutral/bmp/ui/rectframe.c"
#include "../../neutral/bmp/ui/roundframe.c"

#include "../../neutral/bmp/detect.c"


#include "./darkmode.c"
#include "./dwm.c"
#include "./property.c"
#include "./rect.c"
#include "./style.c"




#define N_WIN_FLUENT_UI_OVERRIDE ( 2 )




static n_posix_bool n_win_fluent_ui_onoff = n_posix_false;




void
n_win_fluent_ui( void )
{

	if ( n_win_style_is_classic() )
	{
		n_win_fluent_ui_onoff = n_posix_false;
	} else {
		if ( n_sysinfo_version_8_or_later() )
		{
			n_win_fluent_ui_onoff = n_posix_true;
		}
	}


	return;
}

u32
n_win_fluent_ui_accent_color( void )
{

	u32 fg = n_win_dwm_windowcolor();
	u32 bg = n_bmp_lightness_replace_pixel( fg, 111 );


	return bg;
}

n_type_gfx
n_win_fluent_ui_round_param( HWND hwnd )
{
	return (n_type_gfx) ( (n_type_real) 5 * n_win_scale( hwnd ) );
}

n_type_gfx
n_win_fluent_ui_shadow_size( HWND hwnd )
{
	return (n_type_gfx) ceil( 6 * n_win_scale( hwnd ) );
}

void
n_win_fluent_ui_shadow_metrics
(
	       HWND  hwnd,
	n_type_gfx *shadow_u,
	n_type_gfx *shadow_d,
	n_type_gfx *shadow_l,
	n_type_gfx *shadow_r
)
{

	n_type_gfx u,d,l,r;

	// [!] : currently hard-coded

	if ( 1 )
	{

		// [!] : more Win11-like shadow

		n_type_gfx s = n_win_fluent_ui_shadow_size( hwnd ) * 3;
		n_type_gfx o = (n_type_gfx) ( (n_type_real) s / 3 * 2 );

		u = 0; // [x] : buggy : not supported yet // [!] : combo popup needs this
		d = o;
		l = o;
		r = o;

	} else {

		// [!] : old shadow : bottom-right

		n_type_gfx s = n_win_fluent_ui_shadow_size( hwnd );

		u = 0;
		d = s;
		l = 0;
		r = s;

	}

	if ( shadow_u != NULL ) { (*shadow_u) = u; }
	if ( shadow_d != NULL ) { (*shadow_d) = d; }
	if ( shadow_l != NULL ) { (*shadow_l) = l; }
	if ( shadow_r != NULL ) { (*shadow_r) = r; }


	return;
}
/*
void
n_win_fluent_ui_draw_roundrect( HDC hdc, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_type_gfx round, COLORREF color, n_type_real alpha )
{

	// [!] : this module is heavy : use other solutions instead

	n_type_gfx tx = 0;
	n_type_gfx ty = 0;
	n_posix_loop
	{//break;

		n_type_real coeff = 0;
		n_bmp_roundrect_detect_coeff( tx, ty, sx, sy, round, &coeff );

		if ( coeff < 1.0 )
		{
			COLORREF c = GetPixel ( hdc, x + tx, y + ty    );

			c = n_win_color_blend( c, color, coeff * alpha );

			             SetPixelV( hdc, x + tx, y + ty, c );
		} else {
			SetPixelV( hdc, x + tx, y + ty, color );
		}

		tx++;
		if ( tx >= sx )
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}
	}


	return;
}
*//*
void
n_win_fluent_ui_draw_mask( HDC hdc, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_type_gfx round, COLORREF color )
{

	// [!] : this module is heavy : use other solutions instead

	round += 4;

	n_type_gfx tx = 0;
	n_type_gfx ty = 0;
	n_posix_loop
	{//break;

		n_type_real coeff = 0;
		n_bmp_roundrect_detect_coeff( tx, ty, sx, sy, round, &coeff );

		if ( coeff < 1.0 )
		{
			COLORREF c = GetPixel ( hdc, x + tx, y + ty    );

			c = n_win_color_blend( c, color, coeff );

			             SetPixelV( hdc, x + tx, y + ty, c );

			ExcludeClipRect( hdc, x + tx, y + ty, x + tx + 1, y + ty + 1 );
		}

		tx++;
		if ( tx >= sx )
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}
	}


	return;
}
*/
void
n_win_fluent_ui_bmp_desktop( HWND hwnd, n_bmp *bmp_desktop )
{

	n_type_gfx dsx = GetSystemMetrics( SM_CXSCREEN );
	n_type_gfx dsy = GetSystemMetrics( SM_CYSCREEN );


	n_gdi_doublebuffer db; n_gdi_doublebuffer_zero( &db );
	HDC hdc_memory = n_gdi_doublebuffer_32bpp_init( &db, hwnd, NULL, dsx,dsy );


	HWND hwnd_desktop = 0;
	HDC   hdc_desktop = GetDC( hwnd_desktop );


	BitBlt( hdc_memory, 0,0,dsx,dsy, hdc_desktop, 0,0, SRCCOPY );

	n_bmp_free_fast( bmp_desktop );
	n_bmp_carboncopy( &db.bmp, bmp_desktop );

	bmp_desktop->transparent_onoff = n_posix_false;


//n_bmp_save_literal( bmp_desktop, "ret.bmp" );


	// [Needed] : Win2000 or earlier

	n_bmp_alpha_visible( bmp_desktop );


	ReleaseDC( hwnd_desktop, hdc_desktop );


	n_gdi_doublebuffer_32bpp_cleanup( &db );


	return;
}

void
n_win_fluent_ui_roundrect_region( HWND hwnd, n_type_gfx sx, n_type_gfx sy, n_type_gfx round )
{

	// [!] : for round rect window
	//
	//	+ use with WS_POPUP window
	//	+ drop shadow is automatically applied by CS_DROPSHADOW
	//	+ for smoother rendering use n_win_fluent_ui_bmp_roundframe()

	n_type_gfx r    = round + 1;
	HRGN       hrgn = CreateRoundRectRgn( 0,0,sx+1,sy+1, r,r );


	// [Needed] : black screen will intercept

	HDC hdc = GetDC( hwnd );

	FillRgn( hdc, hrgn, GetStockObject( NULL_BRUSH ) );

	ReleaseDC( hwnd, hdc );


	SetWindowRgn( hwnd, hrgn, n_posix_true );

	DeleteObject( hrgn );


	return;
}

void
n_win_fluent_ui_label( HWND hgui, RECT *rect, n_posix_char *fontname, n_type_gfx fontsize )
{

	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

	n_posix_char str[ 1024 ];
	n_win_text_get( hgui, str, 1024 );


	COLORREF color_bg = n_win_darkmode_systemcolor( COLOR_WINDOW     );
	COLORREF color_fg = n_win_darkmode_systemcolor( COLOR_WINDOWTEXT );

	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( hgui, sx,sy );

	n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;


	n_type_gfx dpi   = 0;
	n_type_gfx round = 0;
	n_type_gfx frame = 0;

	if ( n_win_fluent_ui_onoff )
	{
		dpi   = n_win_dpi( hgui );
		round = n_win_fluent_ui_round_param( hgui );
		frame = (n_type_gfx) trunc( n_win_scale( hgui ) );

		if ( dpi > 96 ) { frame *= 2; }

		n_win_box( hgui, hdc, rect, color_bg );
		n_bmp_ui_roundframe
		(
			bmp,
			x,y,sx,sy,
			round, frame,
			n_win_darkmode_systemcolor( COLOR_BTNSHADOW ),
			color_bg
		);
	} else {
		n_win_box( hgui, hdc, rect, color_bg );
		n_win_frame( hdc, x,y,sx,sy, color_fg );
	}


	HFONT   hf = n_win_font_name2hfont( fontname, fontsize );
	LOGFONT lf = n_win_font_hfont2logfont( hf );

	DeleteObject( hf );
	lf.lfQuality = ANTIALIASED_QUALITY;
	hf = n_win_font_logfont2hfont( &lf );

	HFONT hf_2 = SelectObject( hdc, hf );


	SetBkMode   ( hdc, TRANSPARENT );
	SetTextColor( hdc,    color_fg );

	n_type_gfx  m     = frame * 2; if ( dpi > 96 ) { frame *= 2; }
	RECT        inner = n_win_rect_tweak( rect, m,m,-m,-m );

	int dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
	DrawText( hdc, str,-1, &inner, dt );


	DeleteObject( SelectObject( hdc, hf_2 ) );


	if ( n_win_fluent_ui_onoff )
	{
		n_bmp_cornermask( bmp, round, 0, n_win_darkmode_systemcolor( COLOR_BTNFACE ) );
	}


	n_gdi_doublebuffer_32bpp_simple_exit();


	return;
}

void
n_win_fluent_ui_progress( HWND hgui, int percent )
{
//n_win_debug_count( GetParent( hgui ) ); return;

	if ( n_posix_false == IsWindowVisible( hgui ) ) { return; }


	// [!] : Init

	n_type_gfx sx,sy; n_win_size( hgui, &sx, &sy );

	HDC    hdc =  n_gdi_doublebuffer_32bpp_simple_init( hgui, sx, sy );
	n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;


	// [!] : Background

	n_posix_bool p_solid        = n_game_progressbar_solid;
	n_posix_bool p_no_round     = n_game_progressbar_no_round;
	n_type_gfx   p_round_div    = n_game_progressbar_round_div;
	n_type_gfx   p_border       = n_game_progressbar_border;
	u32          p_border_color = n_game_progressbar_border_color;

	n_type_gfx scale = (n_type_gfx) trunc( n_win_scale( hgui ) );

	n_game_progressbar_solid        = n_posix_true;
	n_game_progressbar_no_round     = ( n_posix_false == n_win_fluent_ui_onoff );
	n_game_progressbar_round_div    = 4;
	n_game_progressbar_border       = 1 * scale;
	n_game_progressbar_border_color = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW );


	u32 bar_fg = n_win_dwm_windowcolor_arranged();
	u32 bar_bg = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );

	n_bmp_flush( bmp, bar_bg );

	n_game_progressbar( bmp, 0,0,sx,sy, bar_fg,bar_bg, percent, 1, N_GAME_PROGRESSBAR_HORIZONTAL );

	if ( n_game_progressbar_no_round )
	{
		u32 dark    = n_game_progressbar_border_color;
		u32 lighter = n_bmp_white;

		u32 color[ 8 ] = { dark,lighter,dark,lighter, lighter,dark,lighter,dark };
		n_bmp_ui_rectframe( bmp, scale, color );
	}


	n_game_progressbar_solid        = p_solid;
	n_game_progressbar_no_round     = p_no_round;
	n_game_progressbar_round_div    = p_round_div;
	n_game_progressbar_border       = p_border;
	n_game_progressbar_border_color = p_border_color;


	// [!] : Text #1 : Init

	n_posix_char str[ 1024 ];

	if ( percent >= 0 )
	{
		n_posix_sprintf_literal( str, "%d%%", percent );
	} else {
		n_win_text_get( hgui, str, 1024 );
	}


	// [!] : Text #2 : Color

	COLORREF bg;
	COLORREF fg;

	if ( n_win_darkmode_onoff )
	{
		bg = RGB(  66, 66, 66 );
		fg = RGB( 222,222,222 );
	} else {
		bg = n_win_darkmode_systemcolor( COLOR_BTNFACE );
		fg = RGB(   0,  0,  0 );
	}

	SetBkMode   ( hdc, TRANSPARENT );
	SetTextColor( hdc, bg          );


	// [!] : Text #3 : Render

	RECT rect; GetClientRect( hgui, &rect );

	HFONT hf = n_win_font_get( hgui );
	HFONT pf = SelectObject( hdc, hf );

	int dt = DT_NOPREFIX | DT_NOCLIP | ( DT_SINGLELINE | DT_VCENTER ) | DT_CENTER;

	n_type_gfx x = -1;
	n_type_gfx y = -1;
	n_posix_loop
	{
		RECT rect_shadow = rect; n_win_rect_move( &rect_shadow, x,y );
		DrawText( hdc, str, -1, &rect_shadow, dt );

		x++;
		if ( x > 1 )
		{
			x = -1;
			y++;
			if ( y > 1 ) { break; }
		}
	}

	SetTextColor( hdc, fg );
	DrawText( hdc, str, -1, &rect, dt );

	SelectObject( hdc, pf );


	// [!] : Cleanup

	n_gdi_doublebuffer_32bpp_simple_exit();


	return;
}




#endif // _H_NONNON_WIN32_WIN_FLUENT_UI

