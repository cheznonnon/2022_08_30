// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




DWORD
n_oc_IDropTarget_dropeffect( DWORD grfKeyState )
{

	// [!] : this module is used at Explorer to OrangeCat

	DWORD ret = DROPEFFECT_NONE;

	if ( oc.view == N_ORANGECAT_VIEW_INFO )
	{

		if ( info.txtbox[ 0 ].txt.readonly == n_false )
		{
			ret = DROPEFFECT_COPY;
		}

	} else
	if ( oc.view == N_ORANGECAT_VIEW_FILE )
	{
//n_win_hwndprintf_literal( n_IDropTarget_hwnd_target, " %d %d ", path.hover, item.hover );

		if ( path.hover == 0 )
		{

			// [!] : "Computer"

			ret = DROPEFFECT_NONE;

		} else
		if ( path.hover != N_ORANGECAT_NOTHING )
		{

			if ( grfKeyState & MK_LBUTTON )
			{
				ret = DROPEFFECT_MOVE;
			} else {
				ret = DROPEFFECT_COPY;
			}

			if ( path.dnd_wait_onoff == n_false )
			{
				path.dnd_wait_onoff = n_true;
				path.dnd_go         = n_false;
				path.dnd_wait_timer = n_posix_tickcount() + N_ORANGECAT_INTERVAL_PATH;
			} else
			if ( path.dnd_wait_timer < n_posix_tickcount() )
			{
				path.dnd_go = n_true;

				n_bmp_fade_go( &path.fade[ path.hover ], oc_color.path_drop );
				n_oc_path_draw( &path );
			}

		} else
		if ( item.hover == N_ORANGECAT_NOTHING )
		{

			if ( oc.view_is_computer )
			{

				ret = DROPEFFECT_NONE;

			} else
			if ( item.find_onoff )
			{

				ret = DROPEFFECT_NONE;

			} else {

				if ( grfKeyState & MK_LBUTTON )
				{
					ret = DROPEFFECT_MOVE;
				} else {
					ret = DROPEFFECT_COPY;
				}

			}

		} else
		if ( item.hover != N_ORANGECAT_NOTHING )
		{

			if ( grfKeyState & MK_LBUTTON )
			{
				ret = DROPEFFECT_MOVE;
			} else {
				ret = DROPEFFECT_COPY;
			}

			// [x] : this code makes blinking when already focused
			//n_bmp_fade_go( &item.fade[ item.hover ], oc_color.item_hover );
			//n_oc_item_draw( &item );

		}

//n_win_cursor_add_literal( NULL, "Z_CURSOR_DND" );
	}

	return ret;
}

HRESULT __stdcall
n_oc_IDropTarget_DragEnter( void *_this, IDataObject *pDataObject, DWORD grfKeyState, POINTL pt, DWORD *pdwEffect )
{
//n_posix_debug_literal( "n_IDropTarget_DragEnter() : %d", grfKeyState );
//n_win_hwndprintf_literal( n_IDropTarget_hwnd_target, "DragEnter" );


	n_IDropTarget_is_running = n_true;


	if ( pdwEffect != NULL )
	{
		(*pdwEffect) = n_oc_IDropTarget_dropeffect( grfKeyState );
	}


	// [x] : conflict with n_IDropSource_start()
	//
	//	[ Explorer => Application ]
	//	grfKeyState has value
	//
	//	[ Application => Application ]
	//	grfKeyState has zero

	n_IDropTarget_keystate = grfKeyState;

/*
	if ( n_win_is_input( VK_LBUTTON ) ) { n_IDropTarget_keystate |= MK_LBUTTON; }
	if ( n_win_is_input( VK_MBUTTON ) ) { n_IDropTarget_keystate |= MK_MBUTTON; }
	if ( n_win_is_input( VK_RBUTTON ) ) { n_IDropTarget_keystate |= MK_RBUTTON; }
	if ( n_win_is_input( VK_SHIFT   ) ) { n_IDropTarget_keystate |= MK_SHIFT;   }
	if ( n_win_is_input( VK_CONTROL ) ) { n_IDropTarget_keystate |= MK_CONTROL; }
*/

	n_IDropTarget_timer = n_posix_tickcount() + GetDoubleClickTime();


	return S_OK;
}

HRESULT __stdcall
n_oc_IDropTarget_DragOver( void *_this, DWORD grfKeyState, POINTL pt, DWORD *pdwEffect )
{
//n_posix_debug_literal( "n_IDropTarget_DragOver() : %d", grfKeyState );
//n_win_hwndprintf_literal( n_IDropTarget_hwnd_target, "DragOver" );


	n_IDropTarget_is_running = n_true;


	if ( pdwEffect != NULL )
	{
		(*pdwEffect) = n_oc_IDropTarget_dropeffect( grfKeyState );
	}


	if (
		( n_IDropTarget_timer <= n_posix_tickcount() )
		&&
		( n_IDropTarget_hwnd_target != NULL )
		&&
		( n_false == IsZoomed( n_IDropTarget_hwnd_target ) )
	)
	{
		n_IDropTarget_foreground_set( n_IDropTarget_hwnd_target );
	}


	return S_OK;
}




void
n_oc_IDropTarget_init( void )
{

	n_IDropTarget_instance.lpVtbl->DragEnter = (void*) n_oc_IDropTarget_DragEnter;
	n_IDropTarget_instance.lpVtbl->DragOver  = (void*) n_oc_IDropTarget_DragOver;


	return;
}


