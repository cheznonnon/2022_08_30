// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
n_posix_bool
n_oc_find_txt_load( n_txt *txt, n_posix_char *name )
{

	// [!] : this module is based on n_txt_load()


	if ( txt == NULL ) { return n_posix_true; }


	n_type_int bom_offset = 0;


	n_posix_char *stream = NULL;
	n_type_int    byte   = 0;


	txt->unicode = N_TXT_UNICODE_NIL;

	{

		FILE *fp = n_posix_fopen_read( name );
		if ( fp == NULL ) { return n_posix_true; }

		byte = n_posix_stat_size( name );

		if ( byte >= 3 )
		{

			u8 sniffer[ 3 ]; n_posix_fread( sniffer, 3, 1, fp );

			// [!] : remember original spec

			if ( n_unicode_bom_is_utf8   ( sniffer, 3 ) )
			{
				txt->unicode = N_TXT_UNICODE_UTF;
				n_posix_fseek( fp, 3, SEEK_SET );
				byte -= 3;
			} else
			if ( n_unicode_bom_is_utf16_le( sniffer, 2 ) )
			{
				txt->unicode = N_TXT_UNICODE_LIL;
				n_posix_fseek( fp, 2, SEEK_SET );
				byte -= 2;
			} else
			if ( n_unicode_bom_is_utf16_be( sniffer, 2 ) )
			{
				txt->unicode = N_TXT_UNICODE_BIG;
				n_posix_fseek( fp, 2, SEEK_SET );
				byte -= 2;
			} else {
				n_posix_fseek( fp, 0, SEEK_SET );
			}

		}

		stream = n_memory_new( byte );
		n_posix_fread( stream, byte, 1, fp );

		n_posix_fclose( fp );

	}


	// [!] : add stream NUL
	//
	//	unicode : file size may have odd number byte

	{

		n_type_int unit = sizeof( n_posix_char );
		n_type_int pad  = ( byte % unit );
		n_type_int nul  = unit;


		// [!] : stream can be NULL

		stream = n_memory_resize( stream, byte + pad + nul );

		n_posix_char *s = stream;
		s[ ( byte + pad ) / unit ] = N_STRING_CHAR_NUL;

	}


	n_posix_bool is_binary = n_posix_false;

	{

		if ( ( txt->unicode == N_TXT_UNICODE_LIL )||( txt->unicode == N_TXT_UNICODE_BIG ) )
		{

			wchar_t    *ptr = (void*) stream;
			n_type_int  cch = byte / sizeof( wchar_t );

			// [!] : some files have NUL at end of stream

			if ( ( cch != 0 )&&( ptr[ cch ] == L'\0' ) ) { cch--; }

			n_type_int i = 0;
			n_posix_loop
			{

				if ( i >= cch ) { break; }

				if ( ptr[ i ] == L'\0' )
				{
					is_binary = n_posix_true;

					break;
				}

				i++;

			}

		} else {

			char       *ptr = (void*) stream;
			n_type_int  cch = byte / sizeof( char );

			// [!] : some files have NUL at end of stream

			if ( ( cch != 0 )&&( ptr[ cch ] == '\0' ) ) { cch--; }

			n_type_int i = 0;
			n_posix_loop
			{

				if ( i >= cch ) { break; }

				if ( ptr[ i ] == '\0' )
				{
					is_binary = n_posix_true;

					break;
				}

				i++;

			}

		}

	}


	if ( is_binary )
	{
//n_posix_debug_literal( "%s", name );

/*
		txt->unicode = N_TXT_UNICODE_NIL;
		txt->newline = N_TXT_NEWLINE_BINARY;
		txt->stream  = stream;

		return n_posix_false;
*/

		{
			char       *ptr = (void*) stream;
			n_type_int  cch = byte / sizeof( char );

			// [!] : some files have NUL at end of stream

			if ( ( cch != 0 )&&( ptr[ cch ] == '\0' ) ) { cch--; }

			n_type_int i = 0;
			n_posix_loop
			{

				if ( i >= cch ) { break; }

				if ( ptr[ i ] == '\0' )
				{
					ptr[ i ] = ' ';
				}

				i++;

			}

//FILE *fp = n_posix_fopen_write( L"ret.text" );
//n_posix_fwrite( ptr, byte, 1, fp );
//n_posix_fclose( fp );

		}

		txt->unicode = N_TXT_UNICODE_NIL;

	}


	// Decoder

	void         *ptr;
	n_posix_bool  lost = n_posix_false;

#ifdef UNICODE


	if ( txt->unicode == N_TXT_UNICODE_NIL )
	{

		ptr = n_unicode_alloccopy( &byte, stream );
//MessageBoxA( NULL, (char*) ptr, "DEBUG", 0 );


		// [!] : n_posix_false is returned always

		lost = n_unicode_codec_char2wchar_no_bom( ptr, byte );
//MessageBoxW( NULL, (wchar_t*) ptr, L"DEBUG", 0 );


		n_memory_free( stream );


		byte   = n_posix_strlen( (void*) ptr ) * sizeof( wchar_t );
		stream = ptr;

	} else {

		u8 *ptr_u8 = (u8*) stream;

		ptr = n_unicode_alloccopy( &byte, &ptr_u8[ bom_offset ] );


		if ( txt->unicode == N_TXT_UNICODE_BIG )
		{

			n_unicode_endianness( ptr, byte );

		} else
		if ( txt->unicode == N_TXT_UNICODE_UTF )
		{

			n_unicode_utf8_decode_no_bom( ptr, byte );

		}


		n_memory_free( stream );

		//n_unicode_bom_remove( ptr, byte );

		byte   = n_posix_strlen( (void*) ptr ) * sizeof( n_posix_char );
		stream = ptr;

	}


#else // #ifdef UNICODE


	if ( txt->unicode != N_TXT_UNICODE_NIL )
	{

		u8 *ptr_u8 = (u8*) stream;

		ptr = n_unicode_alloccopy( &byte, &ptr_u8[ bom_offset ] );


		if ( txt->unicode == N_TXT_UNICODE_BIG )
		{
			n_unicode_endianness( ptr, byte );
		} else
		if ( txt->unicode == N_TXT_UNICODE_UTF )
		{
			n_unicode_utf8_decode_no_bom( ptr, byte );
		}


//MessageBoxW( NULL, (wchar_t*) ptr, L"DEBUG", 0 );

		lost = n_unicode_codec_wchar2char_no_bom( ptr, byte );

//MessageBoxA( NULL, ptr, "DEBUG", 0 );


		n_memory_free( stream );

		byte   = strlen( ptr );
		stream = ptr;

	}


#endif // #ifdef UNICODE


	txt->stream = stream;


	return n_posix_false;
}


